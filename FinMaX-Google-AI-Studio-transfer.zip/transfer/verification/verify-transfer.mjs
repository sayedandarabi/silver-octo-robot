import fs from "node:fs";
import path from "node:path";

const root = process.cwd();
const required = [
  "package.json", "pnpm-lock.yaml", "app.config.ts", "tsconfig.json", "app", "server", "lib", "shared", "drizzle", "assets", "tests", "docs/Google-AI-Studio-transfer.md", ".env.example", "transfer/sample-data/seed-fixtures.json"
];
const missing = required.filter((item) => !fs.existsSync(path.join(root, item)));
if (missing.length) {
  console.error(`Missing required transfer paths: ${missing.join(", ")}`);
  process.exit(1);
}
const pkg = JSON.parse(fs.readFileSync(path.join(root, "package.json"), "utf8"));
if (pkg.name !== "finmax") throw new Error(`Unexpected package name: ${pkg.name}`);
if (!pkg.scripts?.check || !pkg.scripts?.test || !pkg.scripts?.build) throw new Error("Validation scripts are incomplete");
for (const secretName of ["MANUS_JWT_SECRET", "DATABASE_URL", "TELEGRAM_BOT_TOKEN", "WHATSAPP_ACCESS_TOKEN", "FINMAX_BACKUP_PASSWORD"]) {
  const env = fs.readFileSync(path.join(root, ".env.example"), "utf8");
  if (!env.includes(`${secretName}=`)) throw new Error(`Missing environment declaration: ${secretName}`);
}
for (const forbidden of [".env", ".env.local", ".env.production", ".git"]) {
  if (fs.existsSync(path.join(root, forbidden))) throw new Error(`Forbidden secret/history path included: ${forbidden}`);
}
console.log(`Fin MaX transfer verification passed: ${required.length} required paths present.`);
