CREATE TABLE `businesses` (
	`id` varchar(64) NOT NULL,
	`ownerOpenId` varchar(64) NOT NULL,
	`name` varchar(160) NOT NULL,
	`baseCurrency` varchar(4) NOT NULL DEFAULT 'AFN',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `businesses_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `chartAccounts` (
	`id` varchar(64) NOT NULL,
	`businessId` varchar(64) NOT NULL,
	`code` varchar(16) NOT NULL,
	`name` varchar(160) NOT NULL,
	`accountClass` enum('ASSET','LIABILITY','EQUITY','REVENUE','EXPENSE') NOT NULL,
	`normal` enum('DEBIT','CREDIT') NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `chartAccounts_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `customerLedger` (
	`id` varchar(64) NOT NULL,
	`businessId` varchar(64) NOT NULL,
	`customerId` varchar(64) NOT NULL,
	`type` enum('INVOICE','PAYMENT','RETURN','OPENING') NOT NULL,
	`amount` bigint NOT NULL,
	`currency` varchar(4) NOT NULL DEFAULT 'AFN',
	`reference` varchar(160) NOT NULL DEFAULT '',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `customerLedger_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `customers` (
	`id` varchar(64) NOT NULL,
	`businessId` varchar(64) NOT NULL,
	`name` varchar(160) NOT NULL,
	`phone` varchar(40) NOT NULL DEFAULT '',
	`address` text,
	`group` enum('retail','wholesale','company') NOT NULL DEFAULT 'retail',
	`openingAmount` bigint NOT NULL DEFAULT 0,
	`creditLimit` bigint NOT NULL DEFAULT 0,
	`currency` varchar(4) NOT NULL DEFAULT 'AFN',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `customers_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `inventoryMovements` (
	`id` varchar(64) NOT NULL,
	`businessId` varchar(64) NOT NULL,
	`productId` varchar(64) NOT NULL,
	`warehouseId` varchar(64) NOT NULL,
	`type` enum('IN','OUT','ADJUST') NOT NULL,
	`quantity` bigint NOT NULL,
	`unitCost` bigint NOT NULL DEFAULT 0,
	`currency` varchar(4) NOT NULL DEFAULT 'AFN',
	`reference` varchar(160) NOT NULL DEFAULT '',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `inventoryMovements_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `journalEntries` (
	`id` varchar(64) NOT NULL,
	`businessId` varchar(64) NOT NULL,
	`no` varchar(64) NOT NULL,
	`memo` varchar(240) NOT NULL,
	`postedAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `journalEntries_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `journalLines` (
	`id` varchar(64) NOT NULL,
	`businessId` varchar(64) NOT NULL,
	`entryId` varchar(64) NOT NULL,
	`accountCode` varchar(16) NOT NULL,
	`debit` bigint NOT NULL DEFAULT 0,
	`credit` bigint NOT NULL DEFAULT 0,
	`currency` varchar(4) NOT NULL DEFAULT 'AFN',
	CONSTRAINT `journalLines_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `products` (
	`id` varchar(64) NOT NULL,
	`businessId` varchar(64) NOT NULL,
	`sku` varchar(64) NOT NULL,
	`name` varchar(160) NOT NULL,
	`category` varchar(100) NOT NULL DEFAULT '',
	`unit` varchar(32) NOT NULL DEFAULT 'واحد',
	`sellPrice` bigint NOT NULL DEFAULT 0,
	`minStock` bigint NOT NULL DEFAULT 0,
	`currency` varchar(4) NOT NULL DEFAULT 'AFN',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `products_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `warehouses` (
	`id` varchar(64) NOT NULL,
	`businessId` varchar(64) NOT NULL,
	`name` varchar(120) NOT NULL,
	`code` varchar(32) NOT NULL,
	`branchName` varchar(120) NOT NULL DEFAULT '',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `warehouses_id` PRIMARY KEY(`id`)
);
