ALTER TABLE `customers` MODIFY COLUMN `openingAmount` bigint NOT NULL DEFAULT 0;--> statement-breakpoint
ALTER TABLE `customers` MODIFY COLUMN `creditLimit` bigint NOT NULL DEFAULT 0;--> statement-breakpoint
ALTER TABLE `inventoryMovements` MODIFY COLUMN `unitCost` bigint NOT NULL DEFAULT 0;--> statement-breakpoint
ALTER TABLE `journalLines` MODIFY COLUMN `debit` bigint NOT NULL DEFAULT 0;--> statement-breakpoint
ALTER TABLE `journalLines` MODIFY COLUMN `credit` bigint NOT NULL DEFAULT 0;--> statement-breakpoint
ALTER TABLE `products` MODIFY COLUMN `sellPrice` bigint NOT NULL DEFAULT 0;--> statement-breakpoint
ALTER TABLE `products` MODIFY COLUMN `minStock` bigint NOT NULL DEFAULT 0;