CREATE TABLE `auditLogs` (
	`id` varchar(64) NOT NULL,
	`businessId` varchar(64) NOT NULL,
	`actorOpenId` varchar(64) NOT NULL,
	`action` varchar(64) NOT NULL,
	`entityType` varchar(64) NOT NULL,
	`entityId` varchar(64) NOT NULL,
	`payload` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `auditLogs_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `branches` (
	`id` varchar(64) NOT NULL,
	`businessId` varchar(64) NOT NULL,
	`name` varchar(120) NOT NULL,
	`code` varchar(32) NOT NULL,
	`address` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `branches_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `businessMembers` (
	`id` varchar(64) NOT NULL,
	`businessId` varchar(64) NOT NULL,
	`openId` varchar(64) NOT NULL,
	`role` enum('OWNER','ADMIN','ACCOUNTANT','CASHIER','VIEWER') NOT NULL DEFAULT 'VIEWER',
	`active` int NOT NULL DEFAULT 1,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `businessMembers_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `currencies` (
	`id` varchar(64) NOT NULL,
	`businessId` varchar(64) NOT NULL,
	`code` varchar(4) NOT NULL,
	`name` varchar(64) NOT NULL,
	`symbol` varchar(8) NOT NULL DEFAULT '',
	`isBase` int NOT NULL DEFAULT 0,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `currencies_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `exchangeRates` (
	`id` varchar(64) NOT NULL,
	`businessId` varchar(64) NOT NULL,
	`fromCurrency` varchar(4) NOT NULL,
	`toCurrency` varchar(4) NOT NULL,
	`rateNumerator` bigint NOT NULL,
	`rateDenominator` bigint NOT NULL,
	`effectiveAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `exchangeRates_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `invoiceSettings` (
	`businessId` varchar(64) NOT NULL,
	`title` varchar(160) NOT NULL DEFAULT 'فاکتور فروش',
	`logoPath` varchar(512) NOT NULL DEFAULT '',
	`headerText` text,
	`footerText` text,
	`paperWidth` enum('A4','THERMAL_58','THERMAL_80') NOT NULL DEFAULT 'A4',
	`showSku` int NOT NULL DEFAULT 1,
	`showUnit` int NOT NULL DEFAULT 1,
	`showDiscount` int NOT NULL DEFAULT 1,
	`showTax` int NOT NULL DEFAULT 1,
	`showCustomerPhone` int NOT NULL DEFAULT 1,
	`columnOrder` text,
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `invoiceSettings_businessId` PRIMARY KEY(`businessId`)
);
--> statement-breakpoint
CREATE TABLE `productBarcodes` (
	`id` varchar(64) NOT NULL,
	`businessId` varchar(64) NOT NULL,
	`productId` varchar(64) NOT NULL,
	`barcode` varchar(64) NOT NULL,
	`isPrimary` int NOT NULL DEFAULT 0,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `productBarcodes_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `productCategories` (
	`id` varchar(64) NOT NULL,
	`businessId` varchar(64) NOT NULL,
	`name` varchar(120) NOT NULL,
	`code` varchar(32) NOT NULL DEFAULT '',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `productCategories_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `purchaseExpenses` (
	`id` varchar(64) NOT NULL,
	`businessId` varchar(64) NOT NULL,
	`purchaseId` varchar(64) NOT NULL,
	`category` varchar(80) NOT NULL,
	`amount` bigint NOT NULL,
	`currency` varchar(4) NOT NULL DEFAULT 'AFN',
	`note` varchar(240) NOT NULL DEFAULT '',
	CONSTRAINT `purchaseExpenses_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `purchaseLines` (
	`id` varchar(64) NOT NULL,
	`businessId` varchar(64) NOT NULL,
	`purchaseId` varchar(64) NOT NULL,
	`productId` varchar(64) NOT NULL,
	`quantity` bigint NOT NULL,
	`secondaryQuantity` bigint NOT NULL DEFAULT 0,
	`unitCost` bigint NOT NULL,
	`discount` bigint NOT NULL DEFAULT 0,
	`tax` bigint NOT NULL DEFAULT 0,
	`currency` varchar(4) NOT NULL DEFAULT 'AFN',
	`batchNo` varchar(64) NOT NULL DEFAULT '',
	`expiryDate` date,
	CONSTRAINT `purchaseLines_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `purchases` (
	`id` varchar(64) NOT NULL,
	`businessId` varchar(64) NOT NULL,
	`documentNo` varchar(64) NOT NULL,
	`supplierId` varchar(64) NOT NULL DEFAULT '',
	`warehouseId` varchar(64) NOT NULL DEFAULT '',
	`currency` varchar(4) NOT NULL DEFAULT 'AFN',
	`subtotal` bigint NOT NULL DEFAULT 0,
	`tax` bigint NOT NULL DEFAULT 0,
	`landedCost` bigint NOT NULL DEFAULT 0,
	`total` bigint NOT NULL DEFAULT 0,
	`status` enum('DRAFT','POSTED','VOID') NOT NULL DEFAULT 'POSTED',
	`purchasedAt` timestamp NOT NULL DEFAULT (now()),
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `purchases_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `suppliers` (
	`id` varchar(64) NOT NULL,
	`businessId` varchar(64) NOT NULL,
	`name` varchar(160) NOT NULL,
	`phone` varchar(40) NOT NULL DEFAULT '',
	`address` text,
	`currency` varchar(4) NOT NULL DEFAULT 'AFN',
	`openingAmount` bigint NOT NULL DEFAULT 0,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `suppliers_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `taxRates` (
	`id` varchar(64) NOT NULL,
	`businessId` varchar(64) NOT NULL,
	`name` varchar(80) NOT NULL,
	`percentBasisPoints` bigint NOT NULL DEFAULT 0,
	`accountCode` varchar(16) NOT NULL DEFAULT '',
	`active` int NOT NULL DEFAULT 1,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `taxRates_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `units` (
	`id` varchar(64) NOT NULL,
	`businessId` varchar(64) NOT NULL,
	`name` varchar(64) NOT NULL,
	`code` varchar(16) NOT NULL,
	`kind` enum('COUNT','WEIGHT','LENGTH','VOLUME') NOT NULL DEFAULT 'COUNT',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `units_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
ALTER TABLE `inventoryMovements` ADD `secondaryQuantity` bigint DEFAULT 0 NOT NULL;--> statement-breakpoint
ALTER TABLE `inventoryMovements` ADD `expiryDate` date;--> statement-breakpoint
ALTER TABLE `inventoryMovements` ADD `batchNo` varchar(64) DEFAULT '' NOT NULL;--> statement-breakpoint
ALTER TABLE `products` ADD `categoryId` varchar(64) DEFAULT '' NOT NULL;--> statement-breakpoint
ALTER TABLE `products` ADD `unitId` varchar(64) DEFAULT '' NOT NULL;--> statement-breakpoint
ALTER TABLE `products` ADD `secondaryUnit` varchar(32) DEFAULT '' NOT NULL;--> statement-breakpoint
ALTER TABLE `products` ADD `secondaryPerPrimary` bigint DEFAULT 0 NOT NULL;--> statement-breakpoint
ALTER TABLE `warehouses` ADD `branchId` varchar(64) DEFAULT '' NOT NULL;