CREATE TABLE `checks` (
	`id` varchar(64) NOT NULL,
	`businessId` varchar(64) NOT NULL,
	`number` varchar(64) NOT NULL,
	`type` enum('RECEIVABLE','PAYABLE') NOT NULL,
	`customerId` varchar(64) NOT NULL DEFAULT '',
	`supplierId` varchar(64) NOT NULL DEFAULT '',
	`amount` bigint NOT NULL,
	`currency` varchar(4) NOT NULL DEFAULT 'AFN',
	`dueDate` date NOT NULL,
	`status` enum('PENDING','DEPOSITED','CLEARED','BOUNCED','CANCELLED') NOT NULL DEFAULT 'PENDING',
	`bank` varchar(120) NOT NULL DEFAULT '',
	`note` varchar(240) NOT NULL DEFAULT '',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `checks_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `installmentPlans` (
	`id` varchar(64) NOT NULL,
	`businessId` varchar(64) NOT NULL,
	`saleId` varchar(64) NOT NULL,
	`customerId` varchar(64) NOT NULL,
	`currency` varchar(4) NOT NULL DEFAULT 'AFN',
	`totalAmount` bigint NOT NULL,
	`status` enum('ACTIVE','COMPLETED','OVERDUE','CANCELLED') NOT NULL DEFAULT 'ACTIVE',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `installmentPlans_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `installments` (
	`id` varchar(64) NOT NULL,
	`businessId` varchar(64) NOT NULL,
	`planId` varchar(64) NOT NULL,
	`dueDate` date NOT NULL,
	`amount` bigint NOT NULL,
	`paidAmount` bigint NOT NULL DEFAULT 0,
	`status` enum('DUE','PAID','OVERDUE','CANCELLED') NOT NULL DEFAULT 'DUE',
	`paidAt` timestamp,
	CONSTRAINT `installments_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `inventoryLots` (
	`id` varchar(64) NOT NULL,
	`businessId` varchar(64) NOT NULL,
	`productId` varchar(64) NOT NULL,
	`warehouseId` varchar(64) NOT NULL,
	`purchaseLineId` varchar(64) NOT NULL DEFAULT '',
	`batchNo` varchar(64) NOT NULL DEFAULT '',
	`expiryDate` date,
	`receivedQuantity` bigint NOT NULL,
	`remainingQuantity` bigint NOT NULL,
	`unitCost` bigint NOT NULL,
	`currency` varchar(4) NOT NULL DEFAULT 'AFN',
	`receivedAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `inventoryLots_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `partnerTransactions` (
	`id` varchar(64) NOT NULL,
	`businessId` varchar(64) NOT NULL,
	`partnerId` varchar(64) NOT NULL,
	`type` enum('CAPITAL','WITHDRAWAL','PROFIT_SHARE') NOT NULL,
	`amount` bigint NOT NULL,
	`currency` varchar(4) NOT NULL DEFAULT 'AFN',
	`reference` varchar(160) NOT NULL DEFAULT '',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `partnerTransactions_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `partners` (
	`id` varchar(64) NOT NULL,
	`businessId` varchar(64) NOT NULL,
	`name` varchar(160) NOT NULL,
	`shareBasisPoints` bigint NOT NULL,
	`openingCapital` bigint NOT NULL DEFAULT 0,
	`currency` varchar(4) NOT NULL DEFAULT 'AFN',
	`active` int NOT NULL DEFAULT 1,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `partners_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `saleLines` (
	`id` varchar(64) NOT NULL,
	`businessId` varchar(64) NOT NULL,
	`saleId` varchar(64) NOT NULL,
	`productId` varchar(64) NOT NULL,
	`quantity` bigint NOT NULL,
	`unitPrice` bigint NOT NULL,
	`discount` bigint NOT NULL DEFAULT 0,
	`tax` bigint NOT NULL DEFAULT 0,
	`costOfGoods` bigint NOT NULL DEFAULT 0,
	`currency` varchar(4) NOT NULL DEFAULT 'AFN',
	CONSTRAINT `saleLines_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `salePayments` (
	`id` varchar(64) NOT NULL,
	`businessId` varchar(64) NOT NULL,
	`saleId` varchar(64) NOT NULL,
	`method` enum('CASH','BANK','CREDIT','CHECK') NOT NULL DEFAULT 'CASH',
	`amount` bigint NOT NULL,
	`currency` varchar(4) NOT NULL DEFAULT 'AFN',
	`reference` varchar(120) NOT NULL DEFAULT '',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `salePayments_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `sales` (
	`id` varchar(64) NOT NULL,
	`businessId` varchar(64) NOT NULL,
	`documentNo` varchar(64) NOT NULL,
	`customerId` varchar(64) NOT NULL DEFAULT '',
	`warehouseId` varchar(64) NOT NULL DEFAULT '',
	`currency` varchar(4) NOT NULL DEFAULT 'AFN',
	`subtotal` bigint NOT NULL,
	`discount` bigint NOT NULL DEFAULT 0,
	`tax` bigint NOT NULL DEFAULT 0,
	`total` bigint NOT NULL,
	`paid` bigint NOT NULL DEFAULT 0,
	`receivable` bigint NOT NULL,
	`status` enum('DRAFT','POSTED','VOID') NOT NULL DEFAULT 'POSTED',
	`soldAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `sales_id` PRIMARY KEY(`id`)
);
