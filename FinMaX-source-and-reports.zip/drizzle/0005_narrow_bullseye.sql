CREATE TABLE `backupConfigs` (
	`id` varchar(64) NOT NULL,
	`businessId` varchar(64) NOT NULL,
	`enabled` int NOT NULL DEFAULT 0,
	`frequency` enum('DAILY','WEEKLY') NOT NULL DEFAULT 'DAILY',
	`telegramChatId` varchar(160) NOT NULL DEFAULT '',
	`destination` enum('TELEGRAM','STORAGE') NOT NULL DEFAULT 'TELEGRAM',
	`encryptedKeyHint` varchar(80) NOT NULL DEFAULT '',
	`updatedAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `backupConfigs_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `backupRuns` (
	`id` varchar(64) NOT NULL,
	`businessId` varchar(64) NOT NULL,
	`status` enum('STARTED','COMPLETED','FAILED') NOT NULL DEFAULT 'STARTED',
	`destination` varchar(80) NOT NULL,
	`checksum` varchar(128) NOT NULL DEFAULT '',
	`error` varchar(500) NOT NULL DEFAULT '',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `backupRuns_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `messageLogs` (
	`id` varchar(64) NOT NULL,
	`businessId` varchar(64) NOT NULL,
	`channel` enum('TELEGRAM','WHATSAPP') NOT NULL,
	`recipient` varchar(160) NOT NULL,
	`template` varchar(80) NOT NULL,
	`status` enum('PENDING','SENT','FAILED') NOT NULL DEFAULT 'PENDING',
	`providerMessageId` varchar(160) NOT NULL DEFAULT '',
	`error` varchar(500) NOT NULL DEFAULT '',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `messageLogs_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `productionConsumptions` (
	`id` varchar(64) NOT NULL,
	`businessId` varchar(64) NOT NULL,
	`orderId` varchar(64) NOT NULL,
	`productId` varchar(64) NOT NULL,
	`quantity` bigint NOT NULL,
	`unitCost` bigint NOT NULL,
	`currency` varchar(4) NOT NULL DEFAULT 'AFN',
	CONSTRAINT `productionConsumptions_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `productionOrders` (
	`id` varchar(64) NOT NULL,
	`businessId` varchar(64) NOT NULL,
	`recipeId` varchar(64) NOT NULL,
	`warehouseId` varchar(64) NOT NULL,
	`plannedQuantity` bigint NOT NULL,
	`actualQuantity` bigint NOT NULL,
	`totalCost` bigint NOT NULL DEFAULT 0,
	`currency` varchar(4) NOT NULL DEFAULT 'AFN',
	`status` enum('DRAFT','POSTED','VOID') NOT NULL DEFAULT 'POSTED',
	`producedAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `productionOrders_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `productionOutputs` (
	`id` varchar(64) NOT NULL,
	`businessId` varchar(64) NOT NULL,
	`orderId` varchar(64) NOT NULL,
	`productId` varchar(64) NOT NULL,
	`quantity` bigint NOT NULL,
	`unitCost` bigint NOT NULL,
	`currency` varchar(4) NOT NULL DEFAULT 'AFN',
	CONSTRAINT `productionOutputs_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `recipeLines` (
	`id` varchar(64) NOT NULL,
	`businessId` varchar(64) NOT NULL,
	`recipeId` varchar(64) NOT NULL,
	`materialProductId` varchar(64) NOT NULL,
	`quantity` bigint NOT NULL,
	`unit` varchar(32) NOT NULL,
	CONSTRAINT `recipeLines_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `recipes` (
	`id` varchar(64) NOT NULL,
	`businessId` varchar(64) NOT NULL,
	`productId` varchar(64) NOT NULL,
	`name` varchar(160) NOT NULL,
	`outputQuantity` bigint NOT NULL,
	`unit` varchar(32) NOT NULL,
	`active` int NOT NULL DEFAULT 1,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `recipes_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `updateManifests` (
	`id` varchar(64) NOT NULL,
	`channel` enum('production','beta') NOT NULL DEFAULT 'production',
	`version` varchar(32) NOT NULL,
	`minimumSupportedVersion` varchar(32) NOT NULL,
	`manifestUrl` varchar(500) NOT NULL,
	`checksum` varchar(128) NOT NULL,
	`publishedAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `updateManifests_id` PRIMARY KEY(`id`)
);
