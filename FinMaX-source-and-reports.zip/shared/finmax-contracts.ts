import { z } from "zod";

export const businessIdSchema = z.string().min(1).max(64);
export const idSchema = z.string().min(1).max(64);
export const currencyCodeSchema = z.string().regex(/^[A-Z]{3,4}$/, "currency must be an uppercase ISO-like code");
export const integerStringSchema = z.string().regex(/^\d+$/, "value must be a non-negative integer string");
export const dateStringSchema = z.string().regex(/^\d{4}-\d{2}-\d{2}$/, "date must be YYYY-MM-DD");
export const moneySchema = z.object({ amount: integerStringSchema, currency: currencyCodeSchema });

export const saleCreateSchema = z.object({ businessId: businessIdSchema, id: idSchema.default("sale-preview"), documentNo: z.string().min(1).max(64), customerId: z.string().nullable(), warehouseId: z.string().max(64).default(""), costingMethod: z.enum(["AVERAGE", "FIFO", "LIFO"]).default("AVERAGE"), lines: z.array(z.object({ productId: z.string().max(64).default(""), description: z.string().min(1), quantity: integerStringSchema, unitPrice: moneySchema, discountPercent: integerStringSchema })).min(1), taxPercent: integerStringSchema, paid: integerStringSchema, paymentMethod: z.enum(["CASH", "BANK", "CREDIT", "CHECK"]).default("CASH"), status: z.enum(["DRAFT", "POSTED", "VOID"]).default("POSTED") });
export const expenseCreateSchema = z.object({ businessId: businessIdSchema, category: z.string().min(1).max(64), title: z.string().min(1).max(160), amount: moneySchema, note: z.string().max(500).default("") });
export type SaleCreateInput = z.infer<typeof saleCreateSchema>;
export type ExpenseCreateInput = z.infer<typeof expenseCreateSchema>;

export const businessCreateSchema = z.object({ businessId: businessIdSchema, name: z.string().min(1).max(160), baseCurrency: currencyCodeSchema.default("AFN") });
export const customerCreateSchema = z.object({ businessId: businessIdSchema, id: idSchema, name: z.string().min(1).max(160), phone: z.string().max(40).default(""), address: z.string().max(500).default(""), group: z.enum(["retail", "wholesale", "company"]).default("retail"), openingAmount: integerStringSchema.default("0"), creditLimit: integerStringSchema.default("0"), currency: currencyCodeSchema.default("AFN") });
export const inventoryMovementCreateSchema = z.object({ businessId: businessIdSchema, id: idSchema, productId: idSchema, warehouseId: idSchema, type: z.enum(["IN", "OUT", "ADJUST"]), quantity: integerStringSchema, secondaryQuantity: integerStringSchema.default("0"), unitCost: integerStringSchema, currency: currencyCodeSchema.default("AFN"), reference: z.string().max(160).default(""), expiryDate: dateStringSchema.nullable().default(null), batchNo: z.string().max(64).default("") });
export const journalCreateSchema = z.object({ businessId: businessIdSchema, id: idSchema, no: z.string().min(1).max(64), memo: z.string().min(1).max(240), currency: currencyCodeSchema.default("AFN"), lines: z.array(z.object({ id: idSchema, accountCode: z.string().min(1).max(16), debit: integerStringSchema, credit: integerStringSchema })).min(2) });
export type CustomerCreateInput = z.infer<typeof customerCreateSchema>;
export type InventoryMovementCreateInput = z.infer<typeof inventoryMovementCreateSchema>;
export type JournalCreateInput = z.infer<typeof journalCreateSchema>;

export const categoryCreateSchema = z.object({ businessId: businessIdSchema, id: idSchema, name: z.string().min(1).max(120), code: z.string().max(32).default("") });
export const unitCreateSchema = z.object({ businessId: businessIdSchema, id: idSchema, name: z.string().min(1).max(64), code: z.string().min(1).max(16), kind: z.enum(["COUNT", "WEIGHT", "LENGTH", "VOLUME"]).default("COUNT") });
export const supplierCreateSchema = z.object({ businessId: businessIdSchema, id: idSchema, name: z.string().min(1).max(160), phone: z.string().max(40).default(""), address: z.string().max(500).default(""), currency: currencyCodeSchema.default("AFN"), openingAmount: integerStringSchema.default("0") });
export const branchCreateSchema = z.object({ businessId: businessIdSchema, id: idSchema, name: z.string().min(1).max(120), code: z.string().min(1).max(32), address: z.string().max(500).default("") });
export const barcodeCreateSchema = z.object({ businessId: businessIdSchema, id: idSchema, productId: idSchema, barcode: z.string().min(4).max(64), isPrimary: z.boolean().default(false) });
export const currencyCreateSchema = z.object({ businessId: businessIdSchema, id: idSchema, code: currencyCodeSchema, name: z.string().min(1).max(64), symbol: z.string().max(8).default(""), isBase: z.boolean().default(false) });
export const exchangeRateCreateSchema = z.object({ businessId: businessIdSchema, id: idSchema, fromCurrency: currencyCodeSchema, toCurrency: currencyCodeSchema, rateNumerator: integerStringSchema, rateDenominator: integerStringSchema.refine((value) => value !== "0", "denominator cannot be zero"), effectiveAt: z.string().datetime().optional() });
export const taxRateCreateSchema = z.object({ businessId: businessIdSchema, id: idSchema, name: z.string().min(1).max(80), percentBasisPoints: integerStringSchema, accountCode: z.string().max(16).default(""), active: z.boolean().default(true) });
export const invoiceSettingsSchema = z.object({ businessId: businessIdSchema, title: z.string().min(1).max(160), logoPath: z.string().max(512).default(""), headerText: z.string().max(2000).default(""), footerText: z.string().max(2000).default(""), paperWidth: z.enum(["A4", "THERMAL_58", "THERMAL_80"]).default("A4"), showSku: z.boolean().default(true), showUnit: z.boolean().default(true), showDiscount: z.boolean().default(true), showTax: z.boolean().default(true), showCustomerPhone: z.boolean().default(true), columnOrder: z.array(z.string().max(32)).max(20).default([]) });
export const memberCreateSchema = z.object({ businessId: businessIdSchema, id: idSchema, openId: z.string().min(1).max(64), role: z.enum(["OWNER", "ADMIN", "ACCOUNTANT", "CASHIER", "VIEWER"]).default("VIEWER") });

export const purchaseLineSchema = z.object({ id: idSchema, productId: idSchema, quantity: integerStringSchema, secondaryQuantity: integerStringSchema.default("0"), unitCost: integerStringSchema, discount: integerStringSchema.default("0"), tax: integerStringSchema.default("0"), currency: currencyCodeSchema.default("AFN"), batchNo: z.string().max(64).default(""), expiryDate: dateStringSchema.nullable().default(null) });
export const purchaseExpenseSchema = z.object({ id: idSchema, category: z.string().min(1).max(80), amount: integerStringSchema, currency: currencyCodeSchema.default("AFN"), note: z.string().max(240).default("") });
export const purchaseCreateSchema = z.object({ businessId: businessIdSchema, id: idSchema, documentNo: z.string().min(1).max(64), supplierId: idSchema.default(""), warehouseId: idSchema.default(""), currency: currencyCodeSchema.default("AFN"), lines: z.array(purchaseLineSchema).min(1), expenses: z.array(purchaseExpenseSchema).default([]), status: z.enum(["DRAFT", "POSTED", "VOID"]).default("POSTED"), purchasedAt: z.string().datetime().optional() });
export type CategoryCreateInput = z.infer<typeof categoryCreateSchema>;
export type UnitCreateInput = z.infer<typeof unitCreateSchema>;
export type SupplierCreateInput = z.infer<typeof supplierCreateSchema>;
export type PurchaseCreateInput = z.infer<typeof purchaseCreateSchema>;

export const costingMethodSchema = z.enum(["AVERAGE", "FIFO", "LIFO"]);
export const installmentCreateSchema = z.object({ businessId: businessIdSchema, id: idSchema, saleId: idSchema, customerId: idSchema, currency: currencyCodeSchema.default("AFN"), totalAmount: integerStringSchema, installments: z.array(z.object({ id: idSchema, dueDate: dateStringSchema, amount: integerStringSchema })).min(1) });
export const checkCreateSchema = z.object({ businessId: businessIdSchema, id: idSchema, number: z.string().min(1).max(64), type: z.enum(["RECEIVABLE", "PAYABLE"]), customerId: idSchema.default(""), supplierId: idSchema.default(""), amount: integerStringSchema, currency: currencyCodeSchema.default("AFN"), dueDate: dateStringSchema, bank: z.string().max(120).default(""), note: z.string().max(240).default("") });
export const checkStatusSchema = z.object({ businessId: businessIdSchema, id: idSchema, status: z.enum(["PENDING", "DEPOSITED", "CLEARED", "BOUNCED", "CANCELLED"]) });
export const partnerCreateSchema = z.object({ businessId: businessIdSchema, id: idSchema, name: z.string().min(1).max(160), shareBasisPoints: integerStringSchema, openingCapital: integerStringSchema.default("0"), currency: currencyCodeSchema.default("AFN") });
export const partnerTransactionSchema = z.object({ businessId: businessIdSchema, id: idSchema, partnerId: idSchema, type: z.enum(["CAPITAL", "WITHDRAWAL", "PROFIT_SHARE"]), amount: integerStringSchema, currency: currencyCodeSchema.default("AFN"), reference: z.string().max(160).default("") });
export const saleReportSchema = z.object({ businessId: businessIdSchema, from: dateStringSchema.optional(), to: dateStringSchema.optional(), currency: currencyCodeSchema.default("AFN") });
export type InstallmentCreateInput = z.infer<typeof installmentCreateSchema>;
export type CheckCreateInput = z.infer<typeof checkCreateSchema>;
export type PartnerCreateInput = z.infer<typeof partnerCreateSchema>;

export const recipeCreateSchema = z.object({ businessId: businessIdSchema, id: idSchema, productId: idSchema, name: z.string().min(1).max(160), outputQuantity: integerStringSchema, unit: z.string().min(1).max(32), lines: z.array(z.object({ id: idSchema, materialProductId: idSchema, quantity: integerStringSchema, unit: z.string().min(1).max(32) })).min(1) });
export const productionPostSchema = z.object({ businessId: businessIdSchema, id: idSchema, recipeId: idSchema, warehouseId: idSchema, plannedQuantity: integerStringSchema, actualQuantity: integerStringSchema, currency: currencyCodeSchema.default("AFN"), costingMethod: z.enum(["AVERAGE", "FIFO", "LIFO"]).default("AVERAGE") });
export const reportExportSchema = z.object({ businessId: businessIdSchema, report: z.enum(["SALES", "PURCHASES", "INVENTORY", "PROFIT_LOSS", "TRIAL_BALANCE", "RECEIVABLES", "TAXES"]), format: z.enum(["PDF", "XLSX"]) });
export const messageSendSchema = z.object({ businessId: businessIdSchema, channel: z.enum(["TELEGRAM", "WHATSAPP"]), recipient: z.string().min(1).max(160), template: z.enum(["DAILY_SUMMARY", "BACKUP", "CUSTOM"]), text: z.string().min(1).max(4000) });
export const dailySummarySendSchema = z.object({ businessId: businessIdSchema, channel: z.enum(["TELEGRAM", "WHATSAPP"]), recipient: z.string().min(1).max(160), date: dateStringSchema.optional() });
export const backupConfigSchema = z.object({ businessId: businessIdSchema, enabled: z.boolean(), frequency: z.enum(["DAILY", "WEEKLY"]), destination: z.enum(["TELEGRAM", "STORAGE"]), telegramChatId: z.string().max(160).default(""), password: z.string().min(8).max(256) });
export const backupRunSchema = z.object({ businessId: businessIdSchema, password: z.string().min(8).max(256), destination: z.enum(["TELEGRAM", "STORAGE"]).default("STORAGE") });
export const updateCheckSchema = z.object({ channel: z.enum(["production", "beta"]).default("production"), currentVersion: z.string().min(1).max(32) });
export type RecipeCreateInput = z.infer<typeof recipeCreateSchema>;
export type ProductionPostInput = z.infer<typeof productionPostSchema>;
