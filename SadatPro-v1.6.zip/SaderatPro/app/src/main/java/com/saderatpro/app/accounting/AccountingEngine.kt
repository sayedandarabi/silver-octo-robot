package com.saderatpro.app.accounting

import java.math.BigDecimal
import java.math.RoundingMode
import java.time.LocalDate
import java.util.UUID

/** Pure accounting calculations. UI and translations must not change these rules. */
object AccountingEngine {
    data class Money(val amount: BigDecimal, val currency: String = "AFN") {
        init { require(currency.length in 3..4); require(amount.scale() <= 4) }
        fun normalized(scale: Int = 2) = copy(amount.setScale(scale, RoundingMode.HALF_UP))
        operator fun plus(other: Money): Money { require(currency == other.currency); return Money(amount + other.amount, currency) }
        operator fun minus(other: Money): Money { require(currency == other.currency); return Money(amount - other.amount, currency) }
    }
    data class TaxRule(val name: String, val ratePercent: BigDecimal, val enabled: Boolean = true)
    data class SaleTotals(val subtotal: Money, val discount: Money, val tax: Money, val total: Money)
    data class JournalLine(val accountCode: String, val debit: Money, val credit: Money, val memo: String = "")
    data class JournalEntry(val id: String = UUID.randomUUID().toString(), val documentNo: String, val documentDate: LocalDate, val dueDate: LocalDate? = null, val lines: List<JournalLine>)
    data class InventoryLot(val quantity: BigDecimal, val unitCost: Money, val receivedAt: LocalDate, val lot: String? = null)
    data class InventoryIssue(val quantity: BigDecimal, val cost: Money, val remainingLots: List<InventoryLot>)
    data class Depreciation(val period: Int, val expense: Money, val accumulated: Money, val bookValue: Money)
    data class Payroll(val gross: Money, val overtime: Money, val deductions: Money, val net: Money)

    fun saleTotals(unitPrice: Money, quantity: BigDecimal, discountPercent: BigDecimal = BigDecimal.ZERO, discountAmount: Money? = null, tax: TaxRule? = null): SaleTotals {
        require(quantity >= BigDecimal.ZERO); require(discountPercent in BigDecimal.ZERO..BigDecimal("100"))
        val subtotal = Money(unitPrice.amount.multiply(quantity), unitPrice.currency)
        val percentDiscount = subtotal.amount.multiply(discountPercent).divide(BigDecimal("100"), 4, RoundingMode.HALF_UP)
        val fixedDiscount = discountAmount?.let { require(it.currency == unitPrice.currency); it.amount } ?: BigDecimal.ZERO
        val discountValue = percentDiscount.add(fixedDiscount).min(subtotal.amount).max(BigDecimal.ZERO)
        val taxable = subtotal.amount.subtract(discountValue)
        val taxValue = if (tax?.enabled == true) taxable.multiply(tax.ratePercent).divide(BigDecimal("100"), 4, RoundingMode.HALF_UP) else BigDecimal.ZERO
        return SaleTotals(Money(subtotal.amount, unitPrice.currency), Money(discountValue, unitPrice.currency), Money(taxValue, unitPrice.currency), Money(taxable.add(taxValue), unitPrice.currency).normalized())
    }

    fun convert(money: Money, targetCurrency: String, rate: BigDecimal, rateDate: LocalDate): Money {
        require(rate > BigDecimal.ZERO); require(targetCurrency != money.currency); require(rateDate <= LocalDate.now())
        return Money(money.amount.multiply(rate).setScale(2, RoundingMode.HALF_UP), targetCurrency)
    }

    fun validateBalanced(entry: JournalEntry): Result<Unit> {
        if (entry.documentNo.isBlank()) return Result.failure(IllegalArgumentException("document_no_required"))
        if (entry.lines.isEmpty()) return Result.failure(IllegalArgumentException("journal_lines_required"))
        val currencies = entry.lines.flatMap { listOf(it.debit.currency, it.credit.currency) }.toSet()
        if (currencies.size != 1) return Result.failure(IllegalArgumentException("one_currency_per_entry"))
        if (entry.lines.any { it.debit.amount < BigDecimal.ZERO || it.credit.amount < BigDecimal.ZERO }) return Result.failure(IllegalArgumentException("negative_journal_line"))
        val debit = entry.lines.fold(BigDecimal.ZERO) { total, line -> total + line.debit.amount }
        val credit = entry.lines.fold(BigDecimal.ZERO) { total, line -> total + line.credit.amount }
        return if (debit.compareTo(credit) == 0 && debit > BigDecimal.ZERO) Result.success(Unit) else Result.failure(IllegalArgumentException("unbalanced_journal"))
    }

    fun weightedAverageCost(lots: List<InventoryLot>): Money? {
        if (lots.isEmpty()) return null
        val currency = lots.first().unitCost.currency
        require(lots.all { it.unitCost.currency == currency && it.quantity >= BigDecimal.ZERO })
        val quantity = lots.sumOf { it.quantity }
        if (quantity == BigDecimal.ZERO) return Money(BigDecimal.ZERO, currency)
        val value = lots.sumOf { it.quantity.multiply(it.unitCost.amount) }
        return Money(value.divide(quantity, 8, RoundingMode.HALF_UP).setScale(2, RoundingMode.HALF_UP), currency)
    }

    fun issueFifo(source: List<InventoryLot>, requested: BigDecimal): InventoryIssue {
        require(requested >= BigDecimal.ZERO)
        val available = source.sumOf { it.quantity }
        require(available >= requested) { "negative_inventory" }
        var remaining = requested; var cost = BigDecimal.ZERO; val result = mutableListOf<InventoryLot>()
        for (lot in source.sortedBy { it.receivedAt }) {
            if (remaining == BigDecimal.ZERO) { result += lot; continue }
            val used = lot.quantity.min(remaining); cost += used.multiply(lot.unitCost.amount); remaining -= used
            if (lot.quantity > used) result += lot.copy(quantity = lot.quantity - used)
        }
        val currency = source.firstOrNull()?.unitCost?.currency ?: "AFN"
        return InventoryIssue(requested, Money(cost.setScale(2, RoundingMode.HALF_UP), currency), result)
    }

    fun straightLineDepreciation(cost: Money, salvage: Money, usefulLifePeriods: Int, elapsedPeriods: Int): List<Depreciation> {
        require(cost.currency == salvage.currency); require(usefulLifePeriods > 0); require(elapsedPeriods >= 0)
        val depreciable = (cost.amount - salvage.amount).max(BigDecimal.ZERO)
        val perPeriod = depreciable.divide(BigDecimal(usefulLifePeriods), 8, RoundingMode.HALF_UP)
        return (1..elapsedPeriods).map { period ->
            val accumulated = perPeriod.multiply(BigDecimal(period)).min(depreciable).setScale(2, RoundingMode.HALF_UP)
            Depreciation(period, Money(perPeriod.min(depreciable).setScale(2, RoundingMode.HALF_UP), cost.currency), Money(accumulated, cost.currency), Money((cost.amount - accumulated).max(salvage.amount).setScale(2, RoundingMode.HALF_UP), cost.currency))
        }
    }

    fun payroll(base: Money, overtime: Money, allowances: Money, deductions: Money): Payroll {
        require(listOf(base.amount, overtime.amount, allowances.amount, deductions.amount).all { it >= BigDecimal.ZERO })
        val gross = base + overtime + allowances
        return Payroll(gross, overtime, deductions, Money((gross.amount - deductions.amount).max(BigDecimal.ZERO).setScale(2, RoundingMode.HALF_UP), gross.currency))
    }
}
