package com.saderatpro.app.invoice

import java.math.BigDecimal
import java.math.RoundingMode

data class InvoiceLineInput(val description: String, val quantity: BigDecimal, val unitPrice: BigDecimal, val discountPercent: BigDecimal = BigDecimal.ZERO)
data class InvoiceLineResult(val description: String, val quantity: BigDecimal, val unitPrice: BigDecimal, val subtotal: BigDecimal, val discount: BigDecimal, val total: BigDecimal)
data class InvoiceTotals(val subtotal: BigDecimal, val discount: BigDecimal, val tax: BigDecimal, val total: BigDecimal, val paid: BigDecimal, val receivable: BigDecimal)

object InvoiceEngine {
    fun line(input: InvoiceLineInput): InvoiceLineResult {
        require(input.description.isNotBlank() && input.quantity > BigDecimal.ZERO && input.unitPrice >= BigDecimal.ZERO)
        require(input.discountPercent >= BigDecimal.ZERO && input.discountPercent <= BigDecimal("100"))
        val subtotal = input.quantity.multiply(input.unitPrice)
        val discount = subtotal.multiply(input.discountPercent).divide(BigDecimal("100"), 8, RoundingMode.HALF_UP)
        return InvoiceLineResult(input.description, input.quantity, input.unitPrice, subtotal.money(), discount.money(), (subtotal - discount).money())
    }

    fun totals(lines: List<InvoiceLineResult>, taxPercent: BigDecimal, paid: BigDecimal): InvoiceTotals {
        require(lines.isNotEmpty() && taxPercent >= BigDecimal.ZERO && paid >= BigDecimal.ZERO)
        val subtotal = lines.sumOf { it.subtotal }; val discount = lines.sumOf { it.discount }; val taxable = lines.sumOf { it.total }
        val tax = taxable.multiply(taxPercent).divide(BigDecimal("100"), 8, RoundingMode.HALF_UP).money()
        val total = (taxable + tax).money(); val paidSafe = paid.min(total).money()
        return InvoiceTotals(subtotal.money(), discount.money(), tax, total, paidSafe, (total - paidSafe).max(BigDecimal.ZERO).money())
    }

    private fun BigDecimal.money() = setScale(2, RoundingMode.HALF_UP)
}
