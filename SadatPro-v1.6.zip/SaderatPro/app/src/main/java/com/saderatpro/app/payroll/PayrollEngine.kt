package com.saderatpro.app.payroll

import java.math.BigDecimal
import java.math.RoundingMode

data class TaxBracket(val lower: BigDecimal, val upper: BigDecimal?, val fixedTax: BigDecimal, val marginalRatePercent: BigDecimal)
data class PayrollInput(val base: BigDecimal, val allowances: BigDecimal = BigDecimal.ZERO, val overtime: BigDecimal = BigDecimal.ZERO, val deductions: BigDecimal = BigDecimal.ZERO, val advance: BigDecimal = BigDecimal.ZERO, val loanRepayment: BigDecimal = BigDecimal.ZERO)
data class PayrollResult(val gross: BigDecimal, val taxable: BigDecimal, val withholdingTax: BigDecimal, val totalDeductions: BigDecimal, val net: BigDecimal)

object PayrollEngine {
    /** Published monthly wage schedule used as an editable default, not legal advice. */
    val defaultAfghanistanBrackets = listOf(
        TaxBracket(BigDecimal.ZERO, BigDecimal("5000"), BigDecimal.ZERO, BigDecimal.ZERO),
        TaxBracket(BigDecimal("5000"), BigDecimal("12500"), BigDecimal.ZERO, BigDecimal("2")),
        TaxBracket(BigDecimal("12500"), BigDecimal("100000"), BigDecimal("150"), BigDecimal("10")),
        TaxBracket(BigDecimal("100000"), null, BigDecimal("8900"), BigDecimal("20"))
    )

    fun monthlyWithholding(taxable: BigDecimal, brackets: List<TaxBracket> = defaultAfghanistanBrackets): BigDecimal {
        require(taxable >= BigDecimal.ZERO); require(brackets.isNotEmpty())
        val bracket = brackets.lastOrNull { taxable > it.lower } ?: brackets.first()
        val excess = (taxable - bracket.lower).max(BigDecimal.ZERO)
        return bracket.fixedTax.add(excess.multiply(bracket.marginalRatePercent).divide(BigDecimal("100"), 8, RoundingMode.HALF_UP)).setScale(2, RoundingMode.HALF_UP)
    }

    fun calculate(input: PayrollInput, brackets: List<TaxBracket> = defaultAfghanistanBrackets): PayrollResult {
        require(listOf(input.base, input.allowances, input.overtime, input.deductions, input.advance, input.loanRepayment).all { it >= BigDecimal.ZERO })
        val gross = input.base + input.allowances + input.overtime
        val tax = monthlyWithholding(gross, brackets)
        val deductions = input.deductions + input.advance + input.loanRepayment
        val net = (gross - tax - deductions).max(BigDecimal.ZERO)
        return PayrollResult(gross.setScale(2), gross.setScale(2), tax, deductions.setScale(2), net.setScale(2))
    }
}
