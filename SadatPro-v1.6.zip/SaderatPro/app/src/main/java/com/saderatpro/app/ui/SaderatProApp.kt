package com.saderatpro.app.ui

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Assessment
import androidx.compose.material.icons.filled.AttachMoney
import androidx.compose.material.icons.filled.Balance
import androidx.compose.material.icons.filled.Business
import androidx.compose.material.icons.filled.ChevronLeft
import androidx.compose.material.icons.filled.DarkMode
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.ExpandMore
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Inventory2
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.MoreHoriz
import androidx.compose.material.icons.filled.People
import androidx.compose.material.icons.filled.PointOfSale
import androidx.compose.material.icons.filled.ReceiptLong
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.ShowChart
import androidx.compose.material.icons.filled.SwapHoriz
import androidx.compose.material.icons.filled.Wallet
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Divider
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.saderatpro.app.data.Branch
import com.saderatpro.app.data.Expense
import com.saderatpro.app.data.MoneyAccount
import com.saderatpro.app.data.MoneyMovement
import com.saderatpro.app.data.Employee
import com.saderatpro.app.data.InvoiceDraftLine
import com.saderatpro.app.data.InvoiceSettings
import com.saderatpro.app.data.InvoiceSummary
import com.saderatpro.app.data.PayrollSummary
import com.saderatpro.app.data.Product
import com.saderatpro.app.data.StockRow
import com.saderatpro.app.data.Warehouse
import com.saderatpro.app.data.LocalDb
import com.saderatpro.app.data.Sale

private val Emerald = Color(0xFF08A66A)
private val EmeraldDark = Color(0xFF087B55)
private val Canvas = Color(0xFFF4FAF7)
private val Ink = Color(0xFF17332A)
private val Red = Color(0xFFD95D55)
private val Amber = Color(0xFFE7A63E)
private val Blue = Color(0xFF4B83E8)

enum class AppLanguage { Dari, Pashto, English }
enum class AppMode { Simple, Business, Pro }
enum class Page { Home, Transactions, Reports, More }
enum class EntryType { Sale, Expense }

data class Copy(val app: String, val greeting: String, val dashboard: String, val sales: String, val expenses: String, val profit: String, val balance: String, val quickActions: String, val addSale: String, val addExpense: String, val today: String, val recent: String, val transactions: String, val reports: String, val more: String, val save: String, val title: String, val amount: String, val note: String, val optional: String, val empty: String, val saved: String, val login: String, val register: String, val username: String, val password: String, val create: String, val noAccount: String, val haveAccount: String, val language: String, val dark: String, val mode: String, val simple: String, val business: String, val pro: String, val customers: String, val inventory: String, val debts: String, val settings: String, val logout: String, val close: String, val invalid: String, val local: String, val welcome: String, val all: String, val thisMonth: String, val menu: String)

private val DARI = Copy("سادات پرو", "خوش آمدید", "داشبورد کاروبار", "فروش", "مصارف", "سود خالص", "موجودی نقدی", "عملیات سریع", "ثبت فروش", "ثبت مصرف", "امروز", "آخرین عملیات", "عملیات", "گزارش‌ها", "بیشتر", "ذخیره", "شرح", "مبلغ به افغانی", "یادداشت", "اختیاری", "هنوز عملیاتی ثبت نشده است", "با موفقیت ذخیره شد", "ورود", "ثبت‌نام", "نام کاربری", "رمز عبور", "ساخت حساب", "حساب ندارید؟", "حساب دارید؟", "زبان", "حالت تاریک", "سطح کاروبار", "ساده", "تجارتی", "پرو", "مشتریان", "موجودی گدام", "طلب و بدهی", "تنظیمات", "خروج", "بستن", "مبلغ و شرح معتبر وارد کنید", "آفلاین و امن روی همین دستگاه", "خوش آمدید به حساب شما", "همه", "این ماه", "منوی اصلی")
private val PASHTO = Copy("سادات پرو", "ښه راغلاست", "د سوداګرۍ ډشبورډ", "پلور", "لګښتونه", "خالصه ګټه", "نغدي بیلانس", "چټک عملیات", "پلور ثبتول", "لګښت ثبتول", "نن", "وروستي عملیات", "عملیات", "راپورونه", "نور", "ساتل", "تشریح", "مقدار په افغانی", "یادښت", "اختیاري", "تر اوسه عملیات نشته", "په بریالیتوب خوندي شو", "ننوتل", "راجستر", "کارن نوم", "پټ نوم", "حساب جوړول", "حساب نه لرئ؟", "حساب لرئ؟", "ژبه", "تیاره حالت", "د سوداګرۍ کچه", "ساده", "سوداګریز", "پرو", "پېرودونکي", "ګدام", "پورونه", "امستنې", "وتل", "بندول", "سم مقدار او تشریح ولیکئ", "آفلاین او په همدې وسیله خوندي", "ستاسو حساب ته ښه راغلاست", "ټول", "دا میاشت", "اصلي مینو")
private val ENGLISH = Copy("Sadat Pro", "Welcome", "Business dashboard", "Sales", "Expenses", "Net profit", "Cash balance", "Quick actions", "Add sale", "Add expense", "Today", "Recent activity", "Transactions", "Reports", "More", "Save", "Description", "Amount in AFN", "Note", "optional", "No transactions yet", "Saved successfully", "Login", "Register", "Username", "Password", "Create account", "No account?", "Have an account?", "Language", "Dark mode", "Business level", "Simple", "Business", "Pro", "Customers", "Inventory", "Receivables & debts", "Settings", "Logout", "Close", "Enter a valid amount and description", "Offline and secure on this device", "Welcome to your account", "All", "This month", "Main menu")
private fun copy(language: AppLanguage) = when (language) { AppLanguage.Dari -> DARI; AppLanguage.Pashto -> PASHTO; AppLanguage.English -> ENGLISH }

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SaderatProApp() {
    val context = LocalContext.current
    val db = remember { LocalDb(context.applicationContext) }
    val prefs = remember { context.getSharedPreferences("sadat_preferences", 0) }
    var loggedIn by remember { mutableStateOf(false) }
    var language by remember { mutableStateOf(AppLanguage.values().getOrElse(prefs.getInt("language", 0)) { AppLanguage.Dari }) }
    var mode by remember { mutableStateOf(AppMode.values().getOrElse(prefs.getInt("mode", 1)) { AppMode.Business }) }
    var dark by remember { mutableStateOf(prefs.getBoolean("dark", false)) }
    val c = copy(language)
    MaterialTheme(colorScheme = if (dark) darkColorScheme(primary = Color(0xFF66D5A7), background = Color(0xFF0E1814)) else lightColorScheme(primary = Emerald, background = Canvas)) {
        androidx.compose.runtime.CompositionLocalProvider(LocalLayoutDirection provides if (language == AppLanguage.English) LayoutDirection.Ltr else LayoutDirection.Rtl) {
            if (!loggedIn) LoginScreen(db, language, { loggedIn = true })
            else MainShell(db, c, language, mode, dark, { language = it; prefs.edit().putInt("language", it.ordinal).apply() }, { mode = it; prefs.edit().putInt("mode", it.ordinal).apply() }, { dark = it; prefs.edit().putBoolean("dark", it).apply() }, { loggedIn = false })
        }
    }
}

@Composable
private fun LoginScreen(db: LocalDb, language: AppLanguage, onLogin: () -> Unit) {
    val c = copy(language); var username by remember { mutableStateOf("") }; var password by remember { mutableStateOf("") }; var creating by remember { mutableStateOf(false) }; var message by remember { mutableStateOf("") }
    Box(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background), contentAlignment = Alignment.Center) {
        val pulse by rememberInfiniteTransition(label = "logo").animateFloat(1f, 1.08f, infiniteRepeatable(tween(1400, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "pulse")
        Column(Modifier.fillMaxWidth().padding(26.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Surface(Modifier.size(88.dp).scale(pulse), shape = CircleShape, color = Emerald.copy(alpha = .12f)) { Box(contentAlignment = Alignment.Center) { Icon(Icons.Default.Wallet, null, Modifier.size(42.dp), tint = Emerald) } }
            Spacer(Modifier.height(18.dp)); Text(c.app, fontSize = 32.sp, fontWeight = FontWeight.ExtraBold, color = EmeraldDark); Text(if (creating) c.create else c.welcome, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Spacer(Modifier.height(24.dp)); OutlinedTextField(username, { username = it }, Modifier.fillMaxWidth(), label = { Text(c.username) }, singleLine = true); Spacer(Modifier.height(10.dp)); OutlinedTextField(password, { password = it }, Modifier.fillMaxWidth(), label = { Text(c.password) }, visualTransformation = PasswordVisualTransformation(), keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password), singleLine = true)
            Spacer(Modifier.height(16.dp)); Button(onClick = { if (creating) { if (db.register(username, password)) { message = c.saved; creating = false; password = "" } else message = c.invalid } else { if (db.login(username, password)) onLogin() else message = c.invalid } }, Modifier.fillMaxWidth().height(52.dp), shape = RoundedCornerShape(16.dp)) { Text(if (creating) c.create else c.login, fontSize = 16.sp) }
            TextButton(onClick = { creating = !creating; message = "" }) { Text(if (creating) c.haveAccount else c.noAccount) }; if (message.isNotBlank()) Text(message, color = Red); Text(c.local, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun MainShell(db: LocalDb, c: Copy, language: AppLanguage, mode: AppMode, dark: Boolean, setLanguage: (AppLanguage) -> Unit, setMode: (AppMode) -> Unit, setDark: (Boolean) -> Unit, logout: () -> Unit) {
    var page by remember { mutableStateOf(Page.Home) }; var refresh by remember { mutableIntStateOf(0) }; var entry by remember { mutableStateOf<EntryType?>(null) }; val sheet = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    Scaffold(bottomBar = { NavigationBar { listOf(Page.Home to Icons.Default.Home, Page.Transactions to Icons.Default.ReceiptLong, Page.Reports to Icons.Default.ShowChart, Page.More to Icons.Default.MoreHoriz).forEach { (p, icon) -> NavigationBarItem(p == page, { page = p }, icon = { Icon(icon, null) }, label = { Text(when (p) { Page.Home -> c.dashboard; Page.Transactions -> c.transactions; Page.Reports -> c.reports; Page.More -> c.more }) }) } } }, floatingActionButton = { if (page != Page.More) Button({ entry = EntryType.Sale }, shape = CircleShape, modifier = Modifier.size(62.dp)) { Icon(Icons.Default.Add, null, Modifier.size(28.dp)) } }) { pad -> AnimatedContent(page, transitionSpec = { (fadeIn(tween(250)) togetherWith fadeOut(tween(150))) }, modifier = Modifier.padding(pad), label = "page") { selected -> when (selected) { Page.Home -> Dashboard(db, c, mode, refresh, { entry = it }); Page.Transactions -> Transactions(db, c, refresh, { entry = it }); Page.Reports -> Reports(db, c, refresh); Page.More -> MorePage(db, c, language, mode, dark, setLanguage, setMode, setDark, logout) } } }
    if (entry != null) ModalBottomSheet(onDismissRequest = { entry = null }, sheetState = sheet) { EntrySheet(db, c, entry!!, { entry = null; refresh++ }) }
}

@Composable
private fun Dashboard(db: LocalDb, c: Copy, mode: AppMode, refresh: Int, open: (EntryType) -> Unit) {
    val totals = remember(refresh) { db.totals() }; val pulse by rememberInfiniteTransition(label = "card").animateFloat(1f, 1.015f, infiniteRepeatable(tween(1800), RepeatMode.Reverse), label = "cardPulse")
    LazyColumn(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background).padding(horizontal = 18.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        item { Spacer(Modifier.height(10.dp)); Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) { Column { Text(c.greeting, color = MaterialTheme.colorScheme.onSurfaceVariant); Text(c.dashboard, fontSize = 27.sp, fontWeight = FontWeight.ExtraBold) }; Surface(Modifier.size(46.dp), CircleShape, Emerald.copy(alpha = .12f)) { Box(contentAlignment = Alignment.Center) { Icon(Icons.Default.Business, null, tint = Emerald) } } } }
        item { Card(Modifier.fillMaxWidth().scale(pulse), shape = RoundedCornerShape(28.dp), colors = CardDefaults.cardColors(containerColor = EmeraldDark)) { Column(Modifier.padding(20.dp)) { Text(c.balance, color = Color.White.copy(.75f)); Text("${format(totals.profit)} AFN", color = Color.White, fontSize = 32.sp, fontWeight = FontWeight.ExtraBold); Spacer(Modifier.height(12.dp)); Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) { Text("${totals.salesCount} ${c.sales}", color = Color.White.copy(.8f)); Text("${totals.expensesCount} ${c.expenses}", color = Color.White.copy(.8f)) } } } }
        item { Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) { MetricCard(c.sales, totals.sales, Emerald, Modifier.weight(1f)); MetricCard(c.expenses, totals.expenses, Red, Modifier.weight(1f)); MetricCard(c.profit, totals.profit, Blue, Modifier.weight(1f)) } }
        item { Text(c.quickActions, fontSize = 20.sp, fontWeight = FontWeight.Bold) }
        item { Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) { ActionCard(Icons.Default.PointOfSale, c.addSale, Emerald, { open(EntryType.Sale) }, Modifier.weight(1f)); ActionCard(Icons.Default.DeleteOutline, c.addExpense, Red, { open(EntryType.Expense) }, Modifier.weight(1f)) } }
        item { Text(c.recent, fontSize = 20.sp, fontWeight = FontWeight.Bold) }
        val list = db.getSales().take(4); if (list.isEmpty()) item { EmptyCard(c.empty) } else items(list, key = { it.id }) { SaleRow(it, c) }; item { Spacer(Modifier.height(24.dp)) }
    }
}

@Composable private fun MetricCard(title: String, value: Long, color: Color, modifier: Modifier) { Card(modifier, shape = RoundedCornerShape(18.dp)) { Column(Modifier.padding(12.dp)) { Text(title, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant); Text(format(value), fontWeight = FontWeight.Bold, color = color, fontSize = 16.sp); Text("AFN", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant) } } }
@Composable private fun ActionCard(icon: androidx.compose.ui.graphics.vector.ImageVector, title: String, color: Color, click: () -> Unit, modifier: Modifier) { val c by animateColorAsState(color.copy(alpha = .12f), label = "action"); Card(modifier.height(112.dp).clickable { click() }, shape = RoundedCornerShape(22.dp), colors = CardDefaults.cardColors(containerColor = c)) { Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.SpaceBetween) { Icon(icon, null, tint = color, modifier = Modifier.size(30.dp)); Text(title, fontWeight = FontWeight.Bold) } } }
@Composable private fun EmptyCard(text: String) { Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(18.dp)) { Box(Modifier.padding(24.dp).fillMaxWidth(), contentAlignment = Alignment.Center) { Text(text, color = MaterialTheme.colorScheme.onSurfaceVariant) } } }
@Composable private fun SaleRow(sale: Sale, c: Copy) { Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(18.dp)) { Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) { Surface(Modifier.size(42.dp), CircleShape, Emerald.copy(.12f)) { Box(contentAlignment = Alignment.Center) { Icon(Icons.Default.AttachMoney, null, tint = Emerald) } }; Column(Modifier.weight(1f).padding(horizontal = 12.dp)) { Text(sale.title, fontWeight = FontWeight.Bold); Text(sale.createdAt, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant) }; Text("+${format(sale.amount)}", color = Emerald, fontWeight = FontWeight.Bold) } } }

@Composable private fun Transactions(db: LocalDb, c: Copy, refresh: Int, open: (EntryType) -> Unit) { val sales = db.getSales(); val expenses = db.getExpenses(); Column(Modifier.fillMaxSize().padding(18.dp)) { Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) { Text(c.transactions, fontSize = 27.sp, fontWeight = FontWeight.ExtraBold); IconButton({ open(EntryType.Sale) }) { Icon(Icons.Default.Add, null) } }; Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { FilterChip(true, {}, label = { Text(c.all) }); FilterChip(false, {}, label = { Text(c.thisMonth) }) }; Spacer(Modifier.height(12.dp)); if (sales.isEmpty() && expenses.isEmpty()) EmptyCard(c.empty) else LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) { items(sales) { SaleRow(it, c) }; items(expenses) { ExpenseRow(it, c) } } } }
@Composable private fun ExpenseRow(expense: Expense, c: Copy) { Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(18.dp)) { Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) { Surface(Modifier.size(42.dp), CircleShape, Red.copy(.12f)) { Box(contentAlignment = Alignment.Center) { Icon(Icons.Default.DeleteOutline, null, tint = Red) } }; Column(Modifier.weight(1f).padding(horizontal = 12.dp)) { Text(expense.title, fontWeight = FontWeight.Bold); Text(expense.createdAt, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant) }; Text("-${format(expense.amount)}", color = Red, fontWeight = FontWeight.Bold) } } }

@Composable private fun Reports(db: LocalDb, c: Copy, refresh: Int) { val t = db.totals(); Column(Modifier.fillMaxSize().padding(18.dp)) { Text(c.reports, fontSize = 27.sp, fontWeight = FontWeight.ExtraBold); Text(c.thisMonth, color = MaterialTheme.colorScheme.onSurfaceVariant); Spacer(Modifier.height(18.dp)); Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(24.dp)) { Column(Modifier.padding(20.dp)) { Text(c.profit, fontWeight = FontWeight.Bold); Text("${format(t.profit)} AFN", fontSize = 30.sp, color = if (t.profit >= 0) Emerald else Red, fontWeight = FontWeight.ExtraBold); Spacer(Modifier.height(18.dp)); ReportLine(c.sales, t.sales, t.sales + t.expenses, Emerald); ReportLine(c.expenses, t.expenses, t.sales + t.expenses, Red) } }; Spacer(Modifier.height(14.dp)); Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) { InfoTile(Icons.Default.People, c.customers); InfoTile(Icons.Default.Inventory2, c.inventory) }; Spacer(Modifier.height(10.dp)); InfoTile(Icons.Default.Balance, c.debts) } }
@Composable private fun ReportLine(label: String, value: Long, total: Long, color: Color) { val progress = if (total == 0L) 0f else (value.toFloat() / total).coerceIn(0f, 1f); Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) { Text(label, Modifier.width(75.dp)); LinearProgressIndicator(progress, Modifier.weight(1f).height(9.dp).clip(RoundedCornerShape(8.dp)), color = color); Text(format(value), Modifier.width(85.dp).padding(start = 8.dp), fontSize = 12.sp) } }
@Composable private fun InfoTile(icon: androidx.compose.ui.graphics.vector.ImageVector, title: String) { Card(Modifier.fillMaxWidth().height(74.dp), shape = RoundedCornerShape(18.dp)) { Row(Modifier.padding(15.dp), verticalAlignment = Alignment.CenterVertically) { Icon(icon, null, tint = Emerald); Spacer(Modifier.width(12.dp)); Text(title, fontWeight = FontWeight.Bold); Spacer(Modifier.weight(1f)); Icon(Icons.Default.ChevronLeft, null, tint = MaterialTheme.colorScheme.onSurfaceVariant) } } }

@Composable private fun MorePage(db: LocalDb, c: Copy, language: AppLanguage, mode: AppMode, dark: Boolean, setLanguage: (AppLanguage) -> Unit, setMode: (AppMode) -> Unit, setDark: (Boolean) -> Unit, logout: () -> Unit) {
    var module by remember { mutableStateOf("menu") }
    if (module == "inventory") { InventoryCenter(db, c, { module = "menu" }); return }
    if (module == "branches") { BranchesCenter(db, c, language, { module = "menu" }); return }
    if (module == "money") { CashBankCenter(db, c, language, { module = "menu" }); return }
    if (module == "payroll") { PayrollCenter(db, c, language, { module = "menu" }); return }
    if (module == "invoices") { InvoiceCenter(db, c, language, { module = "menu" }); return }
    LazyColumn(Modifier.fillMaxSize().padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) { item { Text(c.menu, color = MaterialTheme.colorScheme.onSurfaceVariant); Text(c.more, fontSize = 28.sp, fontWeight = FontWeight.ExtraBold) }; item { InfoTile(Icons.Default.People, c.customers) }; item { ModuleTile(Icons.Default.Inventory2, c.inventory) { module = "inventory" } }; item { ModuleTile(Icons.Default.SwapHoriz, if (language == AppLanguage.Dari) "شعبه‌ها و انبارها" else if (language == AppLanguage.Pashto) "څانګې او ګدامونه" else "Branches & warehouses") { module = "branches" } }; item { ModuleTile(Icons.Default.Wallet, if (language == AppLanguage.Dari) "صندوق، بانک و حساب‌ها" else if (language == AppLanguage.Pashto) "صندوق، بانک او حسابونه" else "Cash, banks & accounts") { module = "money" } }; item { ModuleTile(Icons.Default.People, if (language == AppLanguage.Dari) "پرسنل و معاشات" else if (language == AppLanguage.Pashto) "کارکوونکي او معاشونه" else "Personnel & payroll") { module = "payroll" } }; item { ModuleTile(Icons.Default.ReceiptLong, if (language == AppLanguage.Dari) "فاکتورها و فروش رسمی" else if (language == AppLanguage.Pashto) "رسمي فاکتورونه" else "Invoices & official sales") { module = "invoices" } }; item { InfoTile(Icons.Default.Balance, c.debts) }; item { Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(20.dp)) { Column(Modifier.padding(18.dp)) { Row(verticalAlignment = Alignment.CenterVertically) { Icon(Icons.Default.Language, null, tint = Emerald); Spacer(Modifier.width(10.dp)); Text(c.language, fontWeight = FontWeight.Bold) }; Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) { listOf(AppLanguage.Dari to "دری", AppLanguage.Pashto to "پښتو", AppLanguage.English to "English").forEach { (l, label) -> FilterChip(language == l, { setLanguage(l) }, label = { Text(label) }) } }; Divider(Modifier.padding(vertical = 12.dp)); Row(verticalAlignment = Alignment.CenterVertically) { Icon(Icons.Default.DarkMode, null, tint = Emerald); Text(c.dark, Modifier.weight(1f).padding(horizontal = 10.dp)); Switch(dark, setDark) } } } }; item { Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(20.dp)) { Column(Modifier.padding(18.dp)) { Text(c.mode, fontWeight = FontWeight.Bold); listOf(AppMode.Simple to c.simple, AppMode.Business to c.business, AppMode.Pro to c.pro).forEach { (m, label) -> Row(Modifier.fillMaxWidth().clickable { setMode(m) }.padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) { RadioButton(mode == m, { setMode(m) }); Text(label) } } } } }; item { OutlinedButton(logout, Modifier.fillMaxWidth()) { Text(c.logout) } }; item { Spacer(Modifier.height(24.dp)) } } }


@Composable private fun ModuleTile(icon: androidx.compose.ui.graphics.vector.ImageVector, title: String, onClick: () -> Unit) { Card(Modifier.fillMaxWidth().height(74.dp).clickable { onClick() }, shape = RoundedCornerShape(18.dp)) { Row(Modifier.padding(15.dp), verticalAlignment = Alignment.CenterVertically) { Surface(Modifier.size(42.dp), CircleShape, Emerald.copy(.12f)) { Box(contentAlignment = Alignment.Center) { Icon(icon, null, tint = Emerald) } }; Text(title, Modifier.weight(1f).padding(horizontal = 12.dp), fontWeight = FontWeight.Bold); Icon(Icons.Default.ChevronLeft, null, tint = MaterialTheme.colorScheme.onSurfaceVariant) } } }

@Composable private fun InventoryCenter(db: LocalDb, c: Copy, back: () -> Unit) {
    var tab by remember { mutableStateOf("stock") }; var refresh by remember { mutableIntStateOf(0) }; var productForm by remember { mutableStateOf(false) }; var movementForm by remember { mutableStateOf(false) }
    val products = remember(refresh) { db.getProducts() }; val warehouses = remember(refresh) { db.getWarehouses() }; val stock = remember(refresh) { db.stockRows() }; val movements = remember(refresh) { db.stockMovements() }
    Column(Modifier.fillMaxSize().padding(18.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) { IconButton(back) { Icon(Icons.AutoMirrored.Filled.ArrowForward, null) }; Column { Text(c.inventory, fontSize = 27.sp, fontWeight = FontWeight.ExtraBold); Text("${products.size} کالا • ${warehouses.size} انبار", color = MaterialTheme.colorScheme.onSurfaceVariant) } }
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) { FilterChip(tab == "stock", { tab = "stock" }, label = { Text("موجودی") }); FilterChip(tab == "products", { tab = "products" }, label = { Text("کالاها") }); FilterChip(tab == "moves", { tab = "moves" }, label = { Text("گردش") }) }
        Spacer(Modifier.height(12.dp))
        if (tab == "stock") {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) { Button({ movementForm = !movementForm }, Modifier.weight(1f)) { Icon(Icons.Default.SwapHoriz, null); Spacer(Modifier.width(5.dp)); Text("ورود/خروج") }; OutlinedButton({ productForm = !productForm }, Modifier.weight(1f)) { Icon(Icons.Default.Add, null); Spacer(Modifier.width(5.dp)); Text("کالای جدید") } }
            if (movementForm) StockMovementForm(db, products, warehouses, { movementForm = false; refresh++ })
            if (productForm) ProductForm(db, { productForm = false; refresh++ })
            Spacer(Modifier.height(10.dp)); if (stock.isEmpty()) EmptyCard("برای شروع، شعبه، انبار و کالا اضافه کنید") else LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) { items(stock, key = { "${it.product.id}-${it.warehouseId}" }) { StockCard(it) } }
        } else if (tab == "products") {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) { Text("فهرست کالا و خدمات", fontWeight = FontWeight.Bold, fontSize = 19.sp); IconButton({ productForm = !productForm }) { Icon(Icons.Default.Add, null) } }
            if (productForm) ProductForm(db, { productForm = false; refresh++ }); LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) { items(products, key = { it.id }) { ProductCard(it) } }
        } else {
            Text("آخرین ورود، خروج و تعدیل موجودی", fontWeight = FontWeight.Bold, fontSize = 19.sp); Spacer(Modifier.height(8.dp)); if (movements.isEmpty()) EmptyCard(c.empty) else LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) { items(movements, key = { it.id }) { MovementCard(it) } }
        }
    }
}

@Composable private fun ProductForm(db: LocalDb, close: () -> Unit) { var sku by remember { mutableStateOf("") }; var name by remember { mutableStateOf("") }; var sell by remember { mutableStateOf("") }; var min by remember { mutableStateOf("") }; Card(Modifier.fillMaxWidth().padding(vertical = 8.dp).animateContentSize(), shape = RoundedCornerShape(18.dp), colors = CardDefaults.cardColors(containerColor = Emerald.copy(.08f))) { Column(Modifier.padding(14.dp)) { Text("تعریف کالای جدید", fontWeight = FontWeight.Bold); OutlinedTextField(sku, { sku = it }, Modifier.fillMaxWidth(), label = { Text("کد کالا / SKU") }, singleLine = true); Spacer(Modifier.height(6.dp)); OutlinedTextField(name, { name = it }, Modifier.fillMaxWidth(), label = { Text("نام کالا") }, singleLine = true); Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { OutlinedTextField(sell, { sell = it.filter(Char::isDigit) }, Modifier.weight(1f), label = { Text("قیمت فروش") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), singleLine = true); OutlinedTextField(min, { min = it.filter(Char::isDigit) }, Modifier.weight(1f), label = { Text("حداقل موجودی") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), singleLine = true) }; Spacer(Modifier.height(8.dp)); Button({ if (sku.isNotBlank() && name.isNotBlank()) { db.addProduct(sku, "", name, "عمومی", "عدد", 0, sell.toLongOrNull() ?: 0, min.toLongOrNull() ?: 0, false); close() } }, Modifier.fillMaxWidth()) { Text("ذخیره کالا") } } } }

@Composable private fun StockMovementForm(db: LocalDb, products: List<Product>, warehouses: List<Warehouse>, close: () -> Unit) { var type by remember { mutableStateOf("IN") }; var quantity by remember { mutableStateOf("") }; var error by remember { mutableStateOf("") }; Card(Modifier.fillMaxWidth().padding(vertical = 8.dp), shape = RoundedCornerShape(18.dp), colors = CardDefaults.cardColors(containerColor = Blue.copy(.08f))) { Column(Modifier.padding(14.dp)) { Text("ثبت گردش موجودی", fontWeight = FontWeight.Bold); Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { FilterChip(type == "IN", { type = "IN" }, label = { Text("ورود") }); FilterChip(type == "OUT", { type = "OUT" }, label = { Text("خروج") }); FilterChip(type == "ADJUST", { type = "ADJUST" }, label = { Text("تعدیل") }) }; OutlinedTextField(quantity, { quantity = it.filter(Char::isDigit) }, Modifier.fillMaxWidth(), label = { Text("تعداد") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), singleLine = true); if (products.isEmpty() || warehouses.isEmpty()) Text("ابتدا حداقل یک کالا و یک انبار تعریف کنید", color = Red) else Button({ try { db.recordStock(products.first().id, warehouses.first().id, type, quantity.toLongOrNull() ?: 0, "ثبت دستی"); close() } catch (e: Exception) { error = "موجودی کافی نیست یا مقدار نامعتبر است" } }, Modifier.fillMaxWidth()) { Text("ثبت در ${warehouses.first().name} / ${products.first().name}") }; if (error.isNotBlank()) Text(error, color = Red) } } }

@Composable private fun StockCard(row: StockRow) { val low = row.quantity <= row.product.minStock; Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(18.dp)) { Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) { Surface(Modifier.size(42.dp), CircleShape, (if (low) Amber else Emerald).copy(.14f)) { Box(contentAlignment = Alignment.Center) { Icon(Icons.Default.Inventory2, null, tint = if (low) Amber else Emerald) } }; Column(Modifier.weight(1f).padding(horizontal = 10.dp)) { Text(row.product.name, fontWeight = FontWeight.Bold); Text("${row.product.sku} • ${row.warehouseName}", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant) }; Column(horizontalAlignment = Alignment.End) { Text("${row.quantity} ${row.product.unit}", fontWeight = FontWeight.ExtraBold, color = if (low) Amber else Emerald); if (low) Text("کمبود موجودی", fontSize = 10.sp, color = Amber) } } } }
@Composable private fun ProductCard(product: Product) { Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(18.dp)) { Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) { Icon(Icons.Default.Inventory2, null, tint = Emerald); Column(Modifier.weight(1f).padding(horizontal = 12.dp)) { Text(product.name, fontWeight = FontWeight.Bold); Text("${product.sku} • ${product.category}", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant) }; Text("${format(product.sellPrice)} AFN", color = Emerald, fontWeight = FontWeight.Bold) } } }
@Composable private fun MovementCard(m: com.saderatpro.app.data.StockMovement) { Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp)) { Row(Modifier.padding(13.dp), verticalAlignment = Alignment.CenterVertically) { Icon(if (m.type == "OUT") Icons.AutoMirrored.Filled.ArrowBack else Icons.Default.SwapHoriz, null, tint = if (m.type == "OUT") Red else Emerald); Column(Modifier.weight(1f).padding(horizontal = 10.dp)) { Text(m.productName, fontWeight = FontWeight.Bold); Text(m.warehouseName, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant) }; Text("${if (m.type == "OUT") "-" else "+"}${m.quantity}", color = if (m.type == "OUT") Red else Emerald, fontWeight = FontWeight.Bold) } } }

@Composable private fun BranchesCenter(db: LocalDb, c: Copy, language: AppLanguage, back: () -> Unit) { var refresh by remember { mutableIntStateOf(0) }; var branchForm by remember { mutableStateOf(false) }; var warehouseForm by remember { mutableStateOf(false) }; val branches = remember(refresh) { db.getBranches() }; val warehouses = remember(refresh) { db.getWarehouses() }; Column(Modifier.fillMaxSize().padding(18.dp)) { Row(verticalAlignment = Alignment.CenterVertically) { IconButton(back) { Icon(Icons.AutoMirrored.Filled.ArrowForward, null) }; Column { Text(if (language == AppLanguage.Dari) "شعبه‌ها و انبارها" else if (language == AppLanguage.Pashto) "څانګې او ګدامونه" else "Branches & warehouses", fontSize = 25.sp, fontWeight = FontWeight.ExtraBold); Text("${branches.size} شعبه • ${warehouses.size} انبار", color = MaterialTheme.colorScheme.onSurfaceVariant) } }; Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { Button({ branchForm = !branchForm }, Modifier.weight(1f)) { Text("شعبه جدید") }; OutlinedButton({ warehouseForm = !warehouseForm }, Modifier.weight(1f)) { Text("انبار جدید") } }; if (branchForm) BranchForm(db, { branchForm = false; refresh++ }); if (warehouseForm) WarehouseForm(db, branches, { warehouseForm = false; refresh++ }); Spacer(Modifier.height(12.dp)); LazyColumn(verticalArrangement = Arrangement.spacedBy(9.dp)) { items(branches, key = { it.id }) { b -> Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(18.dp)) { Column(Modifier.padding(15.dp)) { Row(verticalAlignment = Alignment.CenterVertically) { Icon(Icons.Default.Business, null, tint = Emerald); Text(b.name, Modifier.weight(1f).padding(horizontal = 10.dp), fontWeight = FontWeight.Bold); Text(b.code, color = Emerald, fontWeight = FontWeight.Bold) }; Text(b.address, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant); warehouses.filter { it.branchId == b.id }.forEach { Text("  ↳ ${it.name} (${it.code})", Modifier.padding(top = 5.dp), fontSize = 12.sp) } } } } } } }
@Composable private fun BranchForm(db: LocalDb, close: () -> Unit) { var name by remember { mutableStateOf("") }; var code by remember { mutableStateOf("") }; var address by remember { mutableStateOf("") }; Card(Modifier.fillMaxWidth().padding(vertical = 8.dp), shape = RoundedCornerShape(18.dp), colors = CardDefaults.cardColors(containerColor = Emerald.copy(.08f))) { Column(Modifier.padding(14.dp)) { Text("ثبت شعبه", fontWeight = FontWeight.Bold); OutlinedTextField(name, { name = it }, Modifier.fillMaxWidth(), label = { Text("نام شعبه") }, singleLine = true); Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { OutlinedTextField(code, { code = it }, Modifier.weight(1f), label = { Text("کد") }, singleLine = true); OutlinedTextField(address, { address = it }, Modifier.weight(2f), label = { Text("نشانی") }, singleLine = true) }; Button({ if (name.isNotBlank() && code.isNotBlank()) { db.addBranch(name, code, address); close() } }, Modifier.fillMaxWidth()) { Text("ذخیره شعبه") } } } }
@Composable private fun WarehouseForm(db: LocalDb, branches: List<Branch>, close: () -> Unit) { var name by remember { mutableStateOf("") }; var code by remember { mutableStateOf("") }; var selectedId by remember { mutableStateOf(branches.firstOrNull()?.id ?: 0L) }; Card(Modifier.fillMaxWidth().padding(vertical = 8.dp), shape = RoundedCornerShape(18.dp), colors = CardDefaults.cardColors(containerColor = Blue.copy(.08f))) { Column(Modifier.padding(14.dp)) { Text("ثبت انبار برای شعبه", fontWeight = FontWeight.Bold); Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) { branches.forEach { b -> FilterChip(selectedId == b.id, { selectedId = b.id }, label = { Text(b.name) }) } }; OutlinedTextField(name, { name = it }, Modifier.fillMaxWidth(), label = { Text("نام انبار") }, singleLine = true); OutlinedTextField(code, { code = it }, Modifier.fillMaxWidth(), label = { Text("کد انبار") }, singleLine = true); Button({ if (selectedId > 0 && name.isNotBlank() && code.isNotBlank()) { db.addWarehouse(selectedId, name, code); close() } }, Modifier.fillMaxWidth()) { Text(if (branches.isEmpty()) "ابتدا شعبه بسازید" else "ذخیره انبار") } } } }


@Composable private fun CashBankCenter(db: LocalDb, c: Copy, language: AppLanguage, back: () -> Unit) {
    var tab by remember { mutableStateOf("accounts") }; var refresh by remember { mutableIntStateOf(0) }; var accountForm by remember { mutableStateOf(false) }; var movementForm by remember { mutableStateOf(false) }
    val accounts = remember(refresh) { db.getMoneyAccounts() }; val movements = remember(refresh) { db.moneyMovements() }
    val title = if (language == AppLanguage.Dari) "صندوق، بانک و حساب‌ها" else if (language == AppLanguage.Pashto) "صندوق، بانک او حسابونه" else "Cash, banks & accounts"
    Column(Modifier.fillMaxSize().padding(18.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) { IconButton(back) { Icon(Icons.AutoMirrored.Filled.ArrowForward, null) }; Column { Text(title, fontSize = 25.sp, fontWeight = FontWeight.ExtraBold); Text("${accounts.size} حساب • ${movements.size} گردش", color = MaterialTheme.colorScheme.onSurfaceVariant) } }
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) { FilterChip(tab == "accounts", { tab = "accounts" }, label = { Text("حساب‌ها") }); FilterChip(tab == "movements", { tab = "movements" }, label = { Text("گردش مالی") }) }
        Spacer(Modifier.height(12.dp))
        if (tab == "accounts") {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) { Button({ movementForm = !movementForm }, Modifier.weight(1f)) { Icon(Icons.Default.SwapHoriz, null); Spacer(Modifier.width(5.dp)); Text("دریافت/پرداخت") }; OutlinedButton({ accountForm = !accountForm }, Modifier.weight(1f)) { Icon(Icons.Default.Add, null); Spacer(Modifier.width(5.dp)); Text("حساب جدید") } }
            if (accountForm) MoneyAccountForm(db, { accountForm = false; refresh++ })
            if (movementForm) MoneyMovementForm(db, accounts, { movementForm = false; refresh++ })
            Spacer(Modifier.height(10.dp)); if (accounts.isEmpty()) EmptyCard("برای شروع یک صندوق یا حساب بانکی بسازید") else LazyColumn(verticalArrangement = Arrangement.spacedBy(9.dp)) { items(accounts, key = { it.id }) { MoneyAccountCard(db, it, refresh) } }
        } else {
            Text("آخرین دریافت، پرداخت، انتقال و کارمزد", fontWeight = FontWeight.Bold, fontSize = 19.sp); Spacer(Modifier.height(8.dp)); if (movements.isEmpty()) EmptyCard(c.empty) else LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) { items(movements, key = { it.id }) { MoneyMovementCard(it) } }
        }
    }
}

@Composable private fun MoneyAccountCard(db: LocalDb, account: MoneyAccount, refresh: Int) { val balance = remember(refresh) { db.moneyBalance(account.id) }; val isBank = account.type == "BANK"; Card(Modifier.fillMaxWidth().animateContentSize(), shape = RoundedCornerShape(21.dp), colors = CardDefaults.cardColors(containerColor = if (isBank) Blue.copy(.08f) else Emerald.copy(.08f))) { Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) { Surface(Modifier.size(48.dp), CircleShape, (if (isBank) Blue else Emerald).copy(.16f)) { Box(contentAlignment = Alignment.Center) { Icon(if (isBank) Icons.Default.Business else Icons.Default.Wallet, null, tint = if (isBank) Blue else Emerald) } }; Column(Modifier.weight(1f).padding(horizontal = 12.dp)) { Text(account.name, fontWeight = FontWeight.Bold); Text(if (isBank) "حساب بانکی • ${account.holder}" else "صندوق نقدی • ${account.holder}", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant) }; Column(horizontalAlignment = Alignment.End) { Text("${format(balance)}", color = if (balance >= 0) Emerald else Red, fontWeight = FontWeight.ExtraBold, fontSize = 18.sp); Text(account.currency, fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant) } } } }

@Composable private fun MoneyAccountForm(db: LocalDb, close: () -> Unit) { var type by remember { mutableStateOf("CASH") }; var name by remember { mutableStateOf("") }; var holder by remember { mutableStateOf("") }; var opening by remember { mutableStateOf("") }; Card(Modifier.fillMaxWidth().padding(vertical = 8.dp), shape = RoundedCornerShape(18.dp), colors = CardDefaults.cardColors(containerColor = Emerald.copy(.08f))) { Column(Modifier.padding(14.dp)) { Text("تعریف صندوق یا حساب بانکی", fontWeight = FontWeight.Bold); Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { FilterChip(type == "CASH", { type = "CASH" }, label = { Text("صندوق نقدی") }); FilterChip(type == "BANK", { type = "BANK" }, label = { Text("حساب بانکی") }) }; OutlinedTextField(name, { name = it }, Modifier.fillMaxWidth(), label = { Text("نام حساب") }, singleLine = true); Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { OutlinedTextField(holder, { holder = it }, Modifier.weight(1f), label = { Text("مسئول / بانک") }, singleLine = true); OutlinedTextField(opening, { opening = it.filter(Char::isDigit) }, Modifier.weight(1f), label = { Text("مانده افتتاحیه AFN") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), singleLine = true) }; Button({ if (name.isNotBlank()) { db.addMoneyAccount(name, type, "AFN", opening.toLongOrNull() ?: 0, holder); close() } }, Modifier.fillMaxWidth()) { Text("ذخیره حساب") } } } }

@Composable private fun MoneyMovementForm(db: LocalDb, accounts: List<MoneyAccount>, close: () -> Unit) { var type by remember { mutableStateOf("IN") }; var amount by remember { mutableStateOf("") }; var selectedId by remember { mutableStateOf(accounts.firstOrNull()?.id ?: 0L) }; var targetId by remember { mutableStateOf(accounts.getOrNull(1)?.id ?: 0L) }; var reference by remember { mutableStateOf("") }; var error by remember { mutableStateOf("") }; Card(Modifier.fillMaxWidth().padding(vertical = 8.dp), shape = RoundedCornerShape(18.dp), colors = CardDefaults.cardColors(containerColor = Blue.copy(.08f))) { Column(Modifier.padding(14.dp)) { Text("ثبت دریافت، پرداخت یا انتقال", fontWeight = FontWeight.Bold); Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) { FilterChip(type == "IN", { type = "IN" }, label = { Text("دریافت") }); FilterChip(type == "OUT", { type = "OUT" }, label = { Text("پرداخت") }); FilterChip(type == "TRANSFER", { type = "TRANSFER" }, label = { Text("انتقال") }); FilterChip(type == "FEE", { type = "FEE" }, label = { Text("کارمزد") }) }; if (accounts.isEmpty()) Text("ابتدا یک حساب بسازید", color = Red) else { Text("حساب مبدأ", fontSize = 12.sp); Row(horizontalArrangement = Arrangement.spacedBy(5.dp)) { accounts.forEach { a -> FilterChip(selectedId == a.id, { selectedId = a.id }, label = { Text(a.name) }) } }; if (type == "TRANSFER") { Text("حساب مقصد", fontSize = 12.sp); Row(horizontalArrangement = Arrangement.spacedBy(5.dp)) { accounts.filter { it.id != selectedId }.forEach { a -> FilterChip(targetId == a.id, { targetId = a.id }, label = { Text(a.name) }) } } }; OutlinedTextField(amount, { amount = it.filter(Char::isDigit) }, Modifier.fillMaxWidth(), label = { Text("مبلغ AFN") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), singleLine = true); OutlinedTextField(reference, { reference = it }, Modifier.fillMaxWidth(), label = { Text("شماره مرجع / توضیح") }, singleLine = true); Button({ try { db.addMoneyMovement(selectedId, if (type == "TRANSFER") targetId else null, type, amount.toLongOrNull() ?: 0, reference, "ثبت دستی"); close() } catch (_: Exception) { error = "مبلغ نامعتبر، حساب مقصد انتخاب نشده یا موجودی کافی نیست" } }, Modifier.fillMaxWidth()) { Text("ثبت گردش") }; if (error.isNotBlank()) Text(error, color = Red) } } } }

@Composable private fun MoneyMovementCard(m: MoneyMovement) { val incoming = m.type == "IN"; Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(17.dp)) { Row(Modifier.padding(13.dp), verticalAlignment = Alignment.CenterVertically) { Icon(if (incoming) Icons.AutoMirrored.Filled.ArrowBack else Icons.Default.SwapHoriz, null, tint = if (incoming) Emerald else Red); Column(Modifier.weight(1f).padding(horizontal = 10.dp)) { Text(m.accountName + (m.targetName?.let { " → $it" } ?: ""), fontWeight = FontWeight.Bold); Text(if (m.reference.isBlank()) m.type else m.reference, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant) }; Text("${if (incoming) "+" else "-"}${format(m.amount)}", color = if (incoming) Emerald else Red, fontWeight = FontWeight.Bold) } } }


@Composable private fun PayrollCenter(db: LocalDb, c: Copy, language: AppLanguage, back: () -> Unit) {
    var tab by remember { mutableStateOf("employees") }; var refresh by remember { mutableIntStateOf(0) }; var form by remember { mutableStateOf(false) }; var period by remember { mutableStateOf("2026-11") }; var error by remember { mutableStateOf("") }
    val employees = remember(refresh) { db.getEmployees() }; val report = remember(refresh) { db.latestPayroll() }; val rows = remember(refresh, report?.id) { report?.let { db.payrollRows(it.id) } ?: emptyList() }
    val title = if (language == AppLanguage.Dari) "پرسنل و معاشات" else if (language == AppLanguage.Pashto) "کارکوونکي او معاشونه" else "Personnel & payroll"
    Column(Modifier.fillMaxSize().padding(18.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) { IconButton(back) { Icon(Icons.AutoMirrored.Filled.ArrowForward, null) }; Column { Text(title, fontSize = 26.sp, fontWeight = FontWeight.ExtraBold); Text("${employees.size} کارمند • گزارش کسر مالیات", color = MaterialTheme.colorScheme.onSurfaceVariant) } }
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) { FilterChip(tab == "employees", { tab = "employees" }, label = { Text("پرسنل") }); FilterChip(tab == "report", { tab = "report" }, label = { Text("لیست معاش") }) }
        Spacer(Modifier.height(12.dp))
        if (tab == "employees") {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) { Button({ form = !form }, Modifier.weight(1f)) { Icon(Icons.Default.People, null); Spacer(Modifier.width(5.dp)); Text("کارمند جدید") }; OutlinedButton({ tab = "report" }, Modifier.weight(1f)) { Icon(Icons.Default.Assessment, null); Spacer(Modifier.width(5.dp)); Text("گزارش معاش") } }
            if (form) EmployeeForm(db, { form = false; refresh++ })
            Spacer(Modifier.height(10.dp)); if (employees.isEmpty()) EmptyCard("برای شروع پرونده کارمند بسازید") else LazyColumn(verticalArrangement = Arrangement.spacedBy(9.dp)) { items(employees, key = { it.id }) { EmployeeCard(it) } }
        } else {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) { OutlinedTextField(period, { period = it.filter { ch -> ch.isDigit() || ch == '-' }.take(7) }, Modifier.weight(1f), label = { Text("دوره YYYY-MM") }, singleLine = true); Button({ try { db.calculatePayroll(period); refresh++; error = "" } catch (_: Exception) { error = "دوره باید به شکل YYYY-MM باشد" } }) { Text("محاسبه") } }
            if (error.isNotBlank()) Text(error, color = Red, modifier = Modifier.padding(top = 5.dp))
            if (report != null) { PayrollSummaryCard(report); Text("گزارش کسر مالیات معاش", fontWeight = FontWeight.Bold, fontSize = 19.sp, modifier = Modifier.padding(top = 12.dp)); Text("جدول پیش‌فرض قابل تنظیم است؛ قبل از تسلیم رسمی با وزارت مالیه یا مشاور مالیاتی تطبیق شود. موعد نمونه پرداخت/تسلیم طبق راهنمای منتشرشده: حداکثر ۱۰ روز پس از پایان ماه.", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(vertical = 5.dp)); LazyColumn(verticalArrangement = Arrangement.spacedBy(7.dp)) { items(rows, key = { it.personnelNo }) { r -> PayrollRowCard(r) } } } else EmptyCard("یک دوره معاش را محاسبه کنید")
        }
    }
}

@Composable private fun EmployeeForm(db: LocalDb, close: () -> Unit) { var no by remember { mutableStateOf("") }; var name by remember { mutableStateOf("") }; var position by remember { mutableStateOf("") }; var tin by remember { mutableStateOf("") }; var base by remember { mutableStateOf("") }; var allowance by remember { mutableStateOf("") }; var overtime by remember { mutableStateOf("") }; var deductions by remember { mutableStateOf("") }; Card(Modifier.fillMaxWidth().padding(vertical = 8.dp).animateContentSize(), shape = RoundedCornerShape(19.dp), colors = CardDefaults.cardColors(containerColor = Emerald.copy(.08f))) { Column(Modifier.padding(14.dp)) { Text("پرونده کارمند و قرارداد معاش", fontWeight = FontWeight.Bold); Row(horizontalArrangement = Arrangement.spacedBy(7.dp)) { OutlinedTextField(no, { no = it }, Modifier.weight(1f), label = { Text("کد پرسنلی") }, singleLine = true); OutlinedTextField(tin, { tin = it }, Modifier.weight(1f), label = { Text("TIN") }, singleLine = true) }; OutlinedTextField(name, { name = it }, Modifier.fillMaxWidth(), label = { Text("نام کامل") }, singleLine = true); OutlinedTextField(position, { position = it }, Modifier.fillMaxWidth(), label = { Text("سمت / وظیفه") }, singleLine = true); Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) { MoneyField("معاش پایه", base, { base = it }, Modifier.weight(1f)); MoneyField("مزایا", allowance, { allowance = it }, Modifier.weight(1f)) }; Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) { MoneyField("اضافه‌کاری", overtime, { overtime = it }, Modifier.weight(1f)); MoneyField("کسورات ثابت", deductions, { deductions = it }, Modifier.weight(1f)) }; Button({ if (no.isNotBlank() && name.isNotBlank()) { db.addEmployee(no, name, "", tin, position, null, base.toLongOrNull() ?: 0, allowance.toLongOrNull() ?: 0, overtime.toLongOrNull() ?: 0, deductions.toLongOrNull() ?: 0); close() } }, Modifier.fillMaxWidth()) { Text("ذخیره پرونده") } } } }
@Composable private fun MoneyField(label: String, value: String, change: (String) -> Unit, modifier: Modifier) { OutlinedTextField(value, { change(it.filter(Char::isDigit)) }, modifier, label = { Text(label) }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), singleLine = true) }
@Composable private fun EmployeeCard(e: Employee) { Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(18.dp)) { Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) { Surface(Modifier.size(43.dp), CircleShape, Blue.copy(.14f)) { Box(contentAlignment = Alignment.Center) { Icon(Icons.Default.People, null, tint = Blue) } }; Column(Modifier.weight(1f).padding(horizontal = 11.dp)) { Text(e.name, fontWeight = FontWeight.Bold); Text("${e.personnelNo} • ${e.position}", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant) }; Column(horizontalAlignment = Alignment.End) { Text("${format(e.baseSalary)} AFN", color = Emerald, fontWeight = FontWeight.Bold); Text("پایه ماهانه", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant) } } } }
@Composable private fun PayrollSummaryCard(r: PayrollSummary) { Card(Modifier.fillMaxWidth().padding(vertical = 8.dp), shape = RoundedCornerShape(20.dp), colors = CardDefaults.cardColors(containerColor = Blue.copy(.09f))) { Column(Modifier.padding(15.dp)) { Text("لیست معاش ${r.period}", fontWeight = FontWeight.Bold, fontSize = 18.sp); Text("${r.employeeCount} کارمند", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant); Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) { StatMini("ناخالص", r.gross); StatMini("مالیات", r.tax); StatMini("خالص", r.net) } } } }
@Composable private fun StatMini(label: String, value: Long) { Column(horizontalAlignment = Alignment.CenterHorizontally) { Text(label, fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant); Text(format(value), fontWeight = FontWeight.ExtraBold, color = Emerald) } }
@Composable private fun PayrollRowCard(r: com.saderatpro.app.data.PayrollRow) { Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp)) { Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) { Column(Modifier.weight(1f)) { Text(r.employeeName, fontWeight = FontWeight.Bold); Text("${r.personnelNo} • مالیات ${format(r.tax)}", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant) }; Text("${format(r.net)} AFN", color = Emerald, fontWeight = FontWeight.Bold) } } }


@Composable private fun InvoiceCenter(db: LocalDb, c: Copy, language: AppLanguage, back: () -> Unit) {
    var refresh by remember { mutableIntStateOf(0) }; var form by remember { mutableStateOf(false) }; var settingsForm by remember { mutableStateOf(false) }; val invoices = remember(refresh) { db.invoices() }; val products = remember(refresh) { db.getProducts() }; val warehouses = remember(refresh) { db.getWarehouses() }; val accounts = remember(refresh) { db.getMoneyAccounts() }
    val title = if (language == AppLanguage.Dari) "فاکتورهای رسمی" else if (language == AppLanguage.Pashto) "رسمي فاکتورونه" else "Official invoices"
    Column(Modifier.fillMaxSize().padding(18.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) { IconButton(back) { Icon(Icons.AutoMirrored.Filled.ArrowForward, null) }; Column(Modifier.weight(1f)) { Text(title, fontSize = 26.sp, fontWeight = FontWeight.ExtraBold); Text("${invoices.size} فاکتور • اتصال به انبار و صندوق", color = MaterialTheme.colorScheme.onSurfaceVariant) }; IconButton({ settingsForm = !settingsForm }) { Icon(Icons.Default.Settings, null) } }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) { Button({ form = !form }, Modifier.weight(1f)) { Icon(Icons.Default.Add, null); Spacer(Modifier.width(5.dp)); Text("فاکتور جدید") }; OutlinedButton({ settingsForm = !settingsForm }, Modifier.weight(1f)) { Text("مشخصات فروشنده") } }
        if (settingsForm) InvoiceSettingsForm(db, { settingsForm = false; refresh++ })
        if (form) InvoiceForm(db, products, warehouses, accounts, { form = false; refresh++ })
        Spacer(Modifier.height(12.dp)); if (invoices.isEmpty()) EmptyCard("هنوز فاکتوری ثبت نشده است") else LazyColumn(verticalArrangement = Arrangement.spacedBy(9.dp)) { items(invoices, key = { it.id }) { InvoiceCard(it) } }
    }
}

@Composable private fun InvoiceSettingsForm(db: LocalDb, close: () -> Unit) { val initial = remember { db.invoiceSettings() }; var name by remember { mutableStateOf(initial.businessName) }; var tin by remember { mutableStateOf(initial.tin) }; var address by remember { mutableStateOf(initial.address) }; var phone by remember { mutableStateOf(initial.phone) }; Card(Modifier.fillMaxWidth().padding(vertical = 8.dp).animateContentSize(), shape = RoundedCornerShape(18.dp), colors = CardDefaults.cardColors(containerColor = Blue.copy(.08f))) { Column(Modifier.padding(14.dp)) { Text("مشخصات صادرکننده فاکتور رسمی", fontWeight = FontWeight.Bold); OutlinedTextField(name, { name = it }, Modifier.fillMaxWidth(), label = { Text("نام کسب‌وکار") }, singleLine = true); Row(horizontalArrangement = Arrangement.spacedBy(7.dp)) { OutlinedTextField(tin, { tin = it }, Modifier.weight(1f), label = { Text("TIN") }, singleLine = true); OutlinedTextField(phone, { phone = it }, Modifier.weight(1f), label = { Text("شماره تماس") }, singleLine = true) }; OutlinedTextField(address, { address = it }, Modifier.fillMaxWidth(), label = { Text("نشانی") }, singleLine = true); Button({ db.saveInvoiceSettings(InvoiceSettings(name, tin, address, phone)); close() }, Modifier.fillMaxWidth()) { Text("ذخیره مشخصات") } } } }

@Composable private fun InvoiceForm(db: LocalDb, products: List<Product>, warehouses: List<Warehouse>, accounts: List<MoneyAccount>, close: () -> Unit) { var invoiceNo by remember { mutableStateOf("INV-${System.currentTimeMillis() % 100000}") }; var customer by remember { mutableStateOf("") }; var customerTin by remember { mutableStateOf("") }; var quantity by remember { mutableStateOf("1") }; var discount by remember { mutableStateOf("0") }; var tax by remember { mutableStateOf("0") }; var paid by remember { mutableStateOf("0") }; var selectedProduct by remember { mutableStateOf(products.firstOrNull()?.id ?: 0L) }; var selectedWarehouse by remember { mutableStateOf(warehouses.firstOrNull()?.id ?: 0L) }; var selectedAccount by remember { mutableStateOf(accounts.firstOrNull()?.id ?: 0L) }; var error by remember { mutableStateOf("") }; val product = products.firstOrNull { it.id == selectedProduct }; val warehouse = warehouses.firstOrNull { it.id == selectedWarehouse }; Card(Modifier.fillMaxWidth().padding(vertical = 8.dp).animateContentSize(), shape = RoundedCornerShape(19.dp), colors = CardDefaults.cardColors(containerColor = Emerald.copy(.08f))) { Column(Modifier.padding(14.dp)) { Text("صدور فاکتور رسمی", fontWeight = FontWeight.Bold, fontSize = 18.sp); OutlinedTextField(invoiceNo, { invoiceNo = it }, Modifier.fillMaxWidth(), label = { Text("شماره فاکتور") }, singleLine = true); Row(horizontalArrangement = Arrangement.spacedBy(7.dp)) { OutlinedTextField(customer, { customer = it }, Modifier.weight(1f), label = { Text("مشتری") }, singleLine = true); OutlinedTextField(customerTin, { customerTin = it }, Modifier.weight(1f), label = { Text("TIN مشتری") }, singleLine = true) }; if (products.isEmpty()) Text("ابتدا کالا تعریف کنید", color = Red) else { Text("کالا", fontSize = 12.sp); Row(horizontalArrangement = Arrangement.spacedBy(5.dp)) { products.take(6).forEach { p -> FilterChip(selectedProduct == p.id, { selectedProduct = p.id }, label = { Text(p.name) }) } }; Row(horizontalArrangement = Arrangement.spacedBy(7.dp)) { MoneyField("تعداد", quantity, { quantity = it }, Modifier.weight(1f)); MoneyField("تخفیف ٪", discount, { discount = it }, Modifier.weight(1f)); MoneyField("مالیات ٪", tax, { tax = it }, Modifier.weight(1f)) }; if (product?.isService != true) { Text("انبار", fontSize = 12.sp); Row(horizontalArrangement = Arrangement.spacedBy(5.dp)) { warehouses.take(6).forEach { w -> FilterChip(selectedWarehouse == w.id, { selectedWarehouse = w.id }, label = { Text(w.name) }) } } }; Row(horizontalArrangement = Arrangement.spacedBy(7.dp)) { MoneyField("پرداخت فعلی", paid, { paid = it }, Modifier.weight(1f)); Text("قیمت: ${format(product?.sellPrice ?: 0)} AFN", Modifier.weight(1f).padding(top = 18.dp), color = Emerald, fontWeight = FontWeight.Bold) }; if ((paid.toLongOrNull() ?: 0) > 0) { Text("حساب دریافت", fontSize = 12.sp); Row(horizontalArrangement = Arrangement.spacedBy(5.dp)) { accounts.forEach { a -> FilterChip(selectedAccount == a.id, { selectedAccount = a.id }, label = { Text(a.name) }) } } }; Button({ try { require(product != null); db.postInvoice(invoiceNo, if (customer.isBlank()) "مشتری نقدی" else customer, customerTin, tax.toLongOrNull() ?: 0, paid.toLongOrNull() ?: 0, if ((paid.toLongOrNull() ?: 0) > 0) selectedAccount else null, "فروش از فاکتور", listOf(InvoiceDraftLine(if (product.isService) null else product.id, if (product.isService) null else warehouse?.id, product.name, quantity.toLongOrNull() ?: 0, product.sellPrice, discount.toLongOrNull() ?: 0))); close() } catch (_: Exception) { error = "کالا، انبار یا موجودی کافی نیست و فاکتور ثبت نشد" } }, Modifier.fillMaxWidth()) { Text("ثبت رسمی و اتصال به انبار/صندوق") }; if (error.isNotBlank()) Text(error, color = Red) } } } }

@Composable private fun InvoiceCard(i: InvoiceSummary) { Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(18.dp)) { Column(Modifier.padding(15.dp)) { Row(verticalAlignment = Alignment.CenterVertically) { Icon(Icons.Default.ReceiptLong, null, tint = Emerald); Text(i.invoiceNo, Modifier.weight(1f).padding(horizontal = 10.dp), fontWeight = FontWeight.Bold); Text(i.status, color = Emerald, fontSize = 11.sp) }; Text(if (i.customerName.isBlank()) "مشتری نقدی" else i.customerName, fontSize = 12.sp); Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) { Text("کل: ${format(i.total)} AFN", fontWeight = FontWeight.Bold); Text("پرداخت: ${format(i.paid)}", color = Emerald); if (i.receivable > 0) Text("نسیه: ${format(i.receivable)}", color = Amber) } } } }

@Composable private fun EntrySheet(db: LocalDb, c: Copy, type: EntryType, close: () -> Unit) { var title by remember { mutableStateOf("") }; var amount by remember { mutableStateOf("") }; var note by remember { mutableStateOf("") }; var error by remember { mutableStateOf(false) }; Text(if (type == EntryType.Sale) c.addSale else c.addExpense, Modifier.padding(horizontal = 22.dp, vertical = 8.dp), fontSize = 24.sp, fontWeight = FontWeight.ExtraBold); Column(Modifier.padding(22.dp)) { OutlinedTextField(title, { title = it }, Modifier.fillMaxWidth(), label = { Text(c.title) }, singleLine = true); Spacer(Modifier.height(10.dp)); OutlinedTextField(amount, { amount = it.filter(Char::isDigit) }, Modifier.fillMaxWidth(), label = { Text(c.amount) }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), singleLine = true); Spacer(Modifier.height(10.dp)); OutlinedTextField(note, { note = it }, Modifier.fillMaxWidth(), label = { Text("${c.note} (${c.optional})") }, minLines = 2); if (error) Text(c.invalid, color = Red, modifier = Modifier.padding(top = 8.dp)); Spacer(Modifier.height(16.dp)); Button(onClick = { val value = amount.toLongOrNull(); if (title.isBlank() || value == null || value < 0) error = true else { if (type == EntryType.Sale) db.addSale(title, value, note) else db.addExpense(title, value, note); close() } }, Modifier.fillMaxWidth().height(52.dp), shape = RoundedCornerShape(16.dp)) { Text(c.save) }; Spacer(Modifier.height(18.dp)) } }

private fun format(value: Long): String = "% ,d".format(value).replace(",", " ").trim()
