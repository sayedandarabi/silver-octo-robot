package com.saderatpro.app.accounting

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import java.math.BigDecimal
import java.time.LocalDate

class AccountingEngineTest {
    private fun m(value: String) = AccountingEngine.Money(BigDecimal(value))

    @Test fun saleTotals_applyDiscountAndTaxPrecisely() {
        val totals = AccountingEngine.saleTotals(m("100.00"), BigDecimal("3"), BigDecimal("10"), tax = AccountingEngine.TaxRule("VAT", BigDecimal("5")))
        assertEquals(BigDecimal("300.00"), totals.subtotal.amount.setScale(2))
        assertEquals(BigDecimal("30.00"), totals.discount.amount.setScale(2))
        assertEquals(BigDecimal("13.50"), totals.tax.amount.setScale(2))
        assertEquals(BigDecimal("283.50"), totals.total.amount.setScale(2))
    }

    @Test fun journalsMustBalance() {
        val good = AccountingEngine.JournalEntry(documentNo = "J-1", documentDate = LocalDate.now(), lines = listOf(AccountingEngine.JournalLine("1000", m("100"), m("0")), AccountingEngine.JournalLine("4000", m("0"), m("100"))))
        val bad = good.copy(lines = listOf(AccountingEngine.JournalLine("1000", m("99"), m("0")), AccountingEngine.JournalLine("4000", m("0"), m("100"))))
        assertTrue(AccountingEngine.validateBalanced(good).isSuccess)
        assertTrue(AccountingEngine.validateBalanced(bad).isFailure)
    }

    @Test fun fifoPreventsNegativeInventory() {
        val issue = AccountingEngine.issueFifo(listOf(AccountingEngine.InventoryLot(BigDecimal("2"), m("10"), LocalDate.of(2026, 1, 1)), AccountingEngine.InventoryLot(BigDecimal("3"), m("12"), LocalDate.of(2026, 2, 1))), BigDecimal("4"))
        assertEquals(BigDecimal("44.00"), issue.cost.amount.setScale(2))
        assertEquals(BigDecimal("1"), issue.remainingLots.sumOf { it.quantity })
    }

    @Test fun depreciationStopsAtSalvageValue() {
        val result = AccountingEngine.straightLineDepreciation(m("1000"), m("100"), 3, 5)
        assertEquals(BigDecimal("100.00"), result.last().bookValue.amount.setScale(2))
    }

    @Test fun payrollNeverGoesBelowZero() {
        val payroll = AccountingEngine.payroll(m("100"), m("20"), m("0"), m("500"))
        assertEquals(BigDecimal.ZERO.setScale(2), payroll.net.amount.setScale(2))
    }
}
