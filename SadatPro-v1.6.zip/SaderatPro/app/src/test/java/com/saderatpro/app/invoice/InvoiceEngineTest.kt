package com.saderatpro.app.invoice

import org.junit.Assert.assertEquals
import org.junit.Test
import java.math.BigDecimal

class InvoiceEngineTest {
    private fun d(v: String) = BigDecimal(v)

    @Test fun totalsApplyDiscountTaxAndPartialPayment() {
        val line = InvoiceEngine.line(InvoiceLineInput("کالا", d("2"), d("100"), d("10")))
        val totals = InvoiceEngine.totals(listOf(line), d("5"), d("50"))
        assertEquals(d("200.00"), totals.subtotal)
        assertEquals(d("20.00"), totals.discount)
        assertEquals(d("9.00"), totals.tax)
        assertEquals(d("189.00"), totals.total)
        assertEquals(d("50.00"), totals.paid)
        assertEquals(d("139.00"), totals.receivable)
    }

    @Test fun paymentCannotExceedInvoiceTotal() {
        val line = InvoiceEngine.line(InvoiceLineInput("service", d("1"), d("100")))
        val totals = InvoiceEngine.totals(listOf(line), d("0"), d("150"))
        assertEquals(d("100.00"), totals.paid)
        assertEquals(d("0.00"), totals.receivable)
    }
}
