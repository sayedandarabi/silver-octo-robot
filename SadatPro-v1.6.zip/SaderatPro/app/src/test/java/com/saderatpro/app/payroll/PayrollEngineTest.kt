package com.saderatpro.app.payroll

import org.junit.Assert.assertEquals
import org.junit.Test
import java.math.BigDecimal

class PayrollEngineTest {
    private fun d(v: String) = BigDecimal(v)

    @Test fun withholdingUsesPublishedMonthlyBrackets() {
        assertEquals(d("0.00"), PayrollEngine.monthlyWithholding(d("5000")))
        assertEquals(d("100.00"), PayrollEngine.monthlyWithholding(d("10000")))
        assertEquals(d("900.00"), PayrollEngine.monthlyWithholding(d("20000")))
        assertEquals(d("10900.00"), PayrollEngine.monthlyWithholding(d("110000")))
    }

    @Test fun payrollCalculatesGrossTaxDeductionsAndNet() {
        val result = PayrollEngine.calculate(PayrollInput(d("12000"), d("1000"), d("500"), d("200"), d("300"), d("500")))
        assertEquals(d("13500.00"), result.gross)
        assertEquals(d("250.00"), result.withholdingTax)
        assertEquals(d("1000.00"), result.totalDeductions)
        assertEquals(d("12250.00"), result.net)
    }

    @Test fun netPayCannotBecomeNegative() {
        val result = PayrollEngine.calculate(PayrollInput(d("6000"), deductions = d("50000")))
        assertEquals(d("0.00"), result.net)
    }
}
